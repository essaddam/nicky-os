//! Moli OS runtime.
//!
//! The [`Hub`] owns the live model of the home (devices, current values,
//! availability, labels), broadcasts every change as an [`Event`], routes
//! validated commands to the driver that owns the target device and keeps an
//! auditable journal of every write. Drivers run under a [`supervisor`] that
//! isolates their failures from the core.
//!
//! [`Event`]: moli_core::Event

mod addresses;
mod computed;
mod counters;
mod dependencies;
mod driver;
pub mod guard;
mod hub;
mod journal_log;
mod keypad;
mod labels;
pub mod media;
mod occurrences;
pub mod orders;
mod private_files;
mod reservations;
mod secrets;
mod state_cache;
mod state_file;
mod stats;
pub mod supervisor;
mod timers;
pub mod voice;

pub use addresses::KnownAddress;
pub use counters::CounterError;
pub use dependencies::{
    BindingRole, DependencyBinding, DependencyConsumer, DependencyConsumerSource,
    DependencyDefinition, DependencyError, DependencyPreview, DependencyView,
};
pub use driver::{
    BoxFuture, CommandMetadata, CommandPermit, CommandRequest, Driver, DriverCtx, MediaPublisher,
    ScopedSecrets, SendPermit,
};
pub use hub::{
    ApprovalError, CORE_NAMESPACE, CommandError, DeviceView, DriverView, Hub, HubOptions,
    LabelError, LabelPatch, MAX_LABEL, Snapshot,
};
pub use keypad::{KeypadCode, KeypadInput, KeypadReceiver};
pub use occurrences::OccurrenceError;
pub use reservations::ReservationRef;
pub use secrets::{MasterKey, forget_secret, set_secret};
pub use state_file::{StateFile, StateFileError};
pub use stats::Stats;
pub use supervisor::spawn_driver;
pub use timers::TimerError;

mod temporal;
pub use temporal::{TemporalError, normalize_temporal, validate_point_value};

/// Normalize and validate the configured civil schedule and its IANA time zone.
pub fn validate_weekly_schedule(
    plan: moli_core::WeeklySchedule,
) -> Result<moli_core::WeeklySchedule, DependencyError> {
    Ok(dependencies::Calendar::new(plan)?.definition().clone())
}

mod scenes;
pub use scenes::{
    SceneError, ScenePreview, SceneRun, SceneScope, SceneScopeTarget, SceneStatus,
    SceneTargetResult, TargetStatus,
};

mod durations;
