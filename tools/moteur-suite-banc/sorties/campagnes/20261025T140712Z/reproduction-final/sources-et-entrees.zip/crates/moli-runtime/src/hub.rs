//! The hub: single source of truth for the live model of the home.

#[path = "temporal_hub.rs"]
mod temporal_hub;

use std::collections::{BTreeMap, HashMap, VecDeque};
use std::path::PathBuf;
use std::sync::atomic::{AtomicBool, AtomicU8, Ordering};

#[path = "computed_clock.rs"]
mod computed_clock;
#[path = "computed_hub.rs"]
mod computed_hub;
#[cfg(test)]
#[path = "computed/tests_hub.rs"]
mod computed_tests;
#[cfg(test)]
#[path = "counter_tests.rs"]
mod counter_tests;
#[path = "dependency_hub.rs"]
mod dependency_hub;
#[cfg(test)]
#[path = "dependencies/tests.rs"]
mod dependency_tests;
#[path = "duration_hub.rs"]
mod duration_hub;
#[cfg(test)]
#[path = "duration_tests.rs"]
mod duration_tests;
#[cfg(test)]
#[path = "scene_computed_tests.rs"]
mod scene_computed_tests;
#[cfg(test)]
#[path = "scene_durability_tests.rs"]
mod scene_durability_tests;
#[path = "scene_execution.rs"]
mod scene_execution;
#[path = "scene_hub.rs"]
mod scene_hub;
#[cfg(test)]
#[path = "scene_tests.rs"]
mod scene_tests;
use std::sync::{Arc, Mutex, PoisonError, RwLock, RwLockReadGuard, RwLockWriteGuard};
use std::time::{Duration, Instant};

#[path = "timer_hub.rs"]
mod timer_hub;

use moli_core::{
    Action, ApprovalRequest, Decision, Device, DeviceId, DriverStatus, Event, InstanceId,
    JournalEntry, Label, Origin, Outcome, PointId, Sample, Value, ValueError, now_ms, validate,
};
use serde::{Deserialize, Serialize};
use tokio::sync::{broadcast, mpsc, oneshot};

use crate::addresses::{self, KnownAddress};
use crate::driver::{Claim, CommandMetadata, CommandRequest};
use crate::guard::{GuardPolicy, GuardStatus, Verdict};
use crate::journal_log::JournalLog;
use crate::secrets::{self, MasterKey, SecretStore};
use crate::state_cache::{self, States};
use crate::{Stats, labels};

const COMMAND_QUEUE: usize = 64;
/// Secret namespace of the hub itself; reserved as a driver id.
pub const CORE_NAMESPACE: &str = "core";

#[derive(Clone, Debug)]
pub struct HubOptions {
    /// Where user labels are persisted. `None` keeps them in memory only.
    pub labels_path: Option<PathBuf>,
    /// Where last known values are cached across restarts. `None` disables it.
    pub state_path: Option<PathBuf>,
    /// Button identities and request receipts, independent of the state cache.
    pub button_state_path: Option<PathBuf>,
    /// Atomic counter values and request receipts, shared by all helper instances.
    /// `None` deliberately keeps them volatile (for isolated test/demo hubs).
    pub counter_state_path: Option<PathBuf>,
    /// Timer generations, deadlines and request receipts, independent of state.json.
    pub timer_state_path: Option<PathBuf>,
    pub timer_clock: fn() -> u64,
    pub temporal_state_path: Option<PathBuf>,
    /// Validated executable definitions, separate from cached values.
    pub dependency_state_path: Option<PathBuf>,
    pub duration_state_path: Option<PathBuf>,
    /// Occurrence wall-clock metadata only; identities never depend on it.
    pub occurrence_clock: fn() -> u64,
    /// Append-only journal file (JSON Lines). `None` keeps it in memory only.
    pub journal_path: Option<PathBuf>,
    /// Where drivers last reached their devices. `None` keeps it in memory only.
    pub addresses_path: Option<PathBuf>,
    /// Entries kept in memory (and reloaded at startup).
    pub journal_capacity: usize,
    /// Encrypted store for credentials drivers obtain at runtime, with its
    /// 64-hex-digit master key. `None` disables it (pairing impossible).
    pub secrets: Option<(PathBuf, MasterKey)>,
    /// Protected rooms and quiet hours (from the configuration file only).
    pub guard: GuardPolicy,
    pub event_capacity: usize,
    pub command_timeout: Duration,
}

impl Default for HubOptions {
    fn default() -> Self {
        Self {
            labels_path: None,
            state_path: None,
            button_state_path: None,
            counter_state_path: None,
            timer_state_path: None,
            timer_clock: now_ms,
            temporal_state_path: None,
            dependency_state_path: None,
            duration_state_path: None,
            occurrence_clock: now_ms,
            journal_path: None,
            addresses_path: None,
            journal_capacity: 500,
            secrets: None,
            guard: GuardPolicy::default(),
            event_capacity: 1024,
            command_timeout: Duration::from_secs(5),
        }
    }
}

#[derive(Debug, Clone, PartialEq, thiserror::Error)]
pub enum CommandError {
    #[error(transparent)]
    Timer(#[from] crate::TimerError),
    #[error(transparent)]
    Temporal(#[from] crate::TemporalError),
    #[error(transparent)]
    Counter(#[from] crate::CounterError),
    #[error(transparent)]
    Occurrence(#[from] crate::OccurrenceError),
    #[error("unknown point")]
    UnknownPoint,
    #[error("point is read-only")]
    ReadOnly,
    #[error("invalid value: {0}")]
    Invalid(#[from] ValueError),
    #[error("{}", moli_i18n::tr!("serveur.commande.acces_expire"))]
    AccessDenied,
    #[error("driver unavailable")]
    DriverUnavailable,
    #[error("driver busy")]
    Busy,
    #[error("driver did not answer in time")]
    Timeout,
    #[error("driver error: {0}")]
    Driver(String),
    /// Held by the guard: a human must approve request `id`.
    #[error("awaiting human approval #{id}: {reason}")]
    NeedsApproval { id: u64, reason: String },
}

#[derive(Debug, Clone, PartialEq, thiserror::Error)]
pub enum ApprovalError {
    #[error("only a human, from the dashboard, can decide")]
    HumanOnly,
    #[error("unknown or already decided request")]
    Unknown,
    #[error("request expired")]
    Expired,
    #[error("this request is about another point than the one shown")]
    Mismatch,
    #[error("approved, but the order failed: {0}")]
    Command(CommandError),
}

/// How long a held order waits for a human.
const APPROVAL_TTL_MS: u64 = 10 * 60 * 1000;
/// Orders waiting for a human, at most: a flood of requests must not bury
/// the dashboard (the oldest gives way, and one per point and origin).
const MAX_PENDING: usize = 50;
/// A point id is `<instance>:<native id>/<key>`: anything longer is noise.
const MAX_POINT: usize = 256;
/// Who acts, as declared by an agent: a name, not a message.
const MAX_ACTOR: usize = 64;

/// An agent's declared name, as journaled: bounded, no control characters.
fn clean_actor(actor: Option<String>) -> Option<String> {
    actor
        .map(|a| {
            a.chars()
                .filter(|c| !c.is_control())
                .take(MAX_ACTOR)
                .collect::<String>()
        })
        .filter(|a| !a.trim().is_empty())
}

#[derive(Default)]
struct CommandContext {
    request_id: Option<String>,
    correlation: Option<String>,
    permit: Option<crate::CommandPermit>,
}

fn command_input_error(point: &PointId, value: &Value) -> Option<CommandError> {
    if moli_core::privacy::code_point(point.as_str()) || moli_core::privacy::private_value(value) {
        return Some(CommandError::UnknownPoint);
    }
    if point.as_str().len() > MAX_POINT
        || matches!(value, Value::Text(t) if t.chars().count() > moli_core::MAX_TEXT)
    {
        return Some(CommandError::Invalid(ValueError::TooLong));
    }
    None
}

/// An order resolved and validated, ready for its driver.
struct Prepared {
    point: PointId,
    device: Arc<Device>,
    key: Arc<str>,
    value: Value,
    commands: mpsc::Sender<CommandRequest>,
}

impl Prepared {
    fn is_operation(&self) -> bool {
        self.device
            .point(&self.key)
            .is_some_and(|point| point.kind.is_operation())
    }

    fn approval_value<'a>(&'a self, original: &'a Value) -> &'a Value {
        if self
            .device
            .point(&self.key)
            .is_some_and(|p| matches!(p.kind, moli_core::Kind::Temporal { .. }))
        {
            &self.value
        } else {
            original
        }
    }
}

#[derive(Debug, Default)]
struct Approvals {
    next_id: u64,
    pending: BTreeMap<u64, Arc<ApprovalRequest>>,
    permits: BTreeMap<u64, crate::CommandPermit>,
}

#[derive(Debug, thiserror::Error)]
pub enum LabelError {
    #[error("unknown device")]
    UnknownDevice,
    #[error("could not persist labels: {0}")]
    Persist(#[from] std::io::Error),
    #[error("{0}")]
    Guarded(String),
}

/// A partial label update: `None` keeps a field, `Some("")` clears it.
#[derive(Clone, Debug, Default, PartialEq, Eq, Deserialize)]
pub struct LabelPatch {
    #[serde(default)]
    pub name: Option<String>,
    #[serde(default)]
    pub room: Option<String>,
}

/// Longest name or room a label may hold: a label is read by people, by
/// agents and by Moli's prompts (never a place to hide instructions).
pub const MAX_LABEL: usize = 60;

/// A label as stored: no control characters, single spaces, bounded.
fn clean_label(s: &str) -> String {
    s.split(|c: char| c.is_whitespace() || c.is_control())
        .filter(|w| !w.is_empty())
        .collect::<Vec<_>>()
        .join(" ")
        .chars()
        .take(MAX_LABEL)
        .collect()
}

impl LabelPatch {
    fn apply(self, current: Label) -> Label {
        let merge = |patch: Option<String>, current: Option<String>| match patch {
            None => current,
            Some(s) => Some(clean_label(&s)).filter(|s| !s.is_empty()),
        };
        Label {
            name: merge(self.name, current.name),
            room: merge(self.room, current.room),
        }
    }
}

/// Everything known about one device, as served to the surfaces.
#[derive(Clone, Debug, Serialize)]
pub struct DeviceView {
    #[serde(flatten)]
    pub device: Arc<Device>,
    pub label: Label,
    pub online: Option<bool>,
    pub state: BTreeMap<Arc<str>, Sample>,
    /// Images on demand (`/api/devices/{id}/snapshot`).
    #[serde(skip_serializing_if = "std::ops::Not::not")]
    pub camera: bool,
    /// Prints documents (`/api/devices/{id}/print`).
    #[serde(skip_serializing_if = "std::ops::Not::not")]
    pub printer: bool,
}

#[derive(Clone, Debug, Serialize)]
pub struct DriverView {
    pub instance: InstanceId,
    pub kind: &'static str,
    /// The catalogue package it runs (see [`crate::Driver::integration`]).
    pub integration: Arc<str>,
    pub status: DriverStatus,
}

#[derive(Clone, Debug, Serialize)]
pub struct Snapshot {
    pub devices: Vec<DeviceView>,
    pub drivers: Vec<DriverView>,
    pub approvals: Vec<Arc<ApprovalRequest>>,
    pub guard: GuardStatus,
}

/// How a command's result reads in the journal.
fn outcome_of(result: &Result<(), CommandError>) -> Outcome {
    match result {
        Ok(()) => Outcome::Ok,
        Err(CommandError::NeedsApproval { id, reason }) => Outcome::Pending(moli_i18n::tr!(
            "serveur.garde.en_attente",
            id = id,
            reason = reason
        )),
        Err(e) => Outcome::Err(e.to_string()),
    }
}

/// Writes an order's journal line, once its outcome is known.
type JournalLine = Box<dyn FnOnce(Outcome) + Send>;

/// The driver's answer, until the deadline.
async fn answer_of(
    answer: &mut oneshot::Receiver<Result<(), CommandError>>,
    deadline: Instant,
) -> Result<(), CommandError> {
    match tokio::time::timeout_at(deadline.into(), answer).await {
        Err(_) => Err(CommandError::Timeout),
        Ok(Err(_)) => Err(CommandError::Driver("command dropped".into())),
        Ok(Ok(result)) => result,
    }
}

/// Waits for a taken order's answer and writes its journal line, once. If
/// it is itself dropped first (its task cancelled, the runtime shutting
/// down), the line is still written: the answer if it has come, otherwise
/// « outcome unknown ».
struct Observer {
    answer: oneshot::Receiver<Result<(), CommandError>>,
    deadline: Instant,
    journal: Option<JournalLine>,
}

impl Observer {
    async fn finish(mut self) -> Result<(), CommandError> {
        let result = answer_of(&mut self.answer, self.deadline).await;
        self.write(outcome_of(&result));
        result
    }

    fn write(&mut self, outcome: Outcome) {
        if let Some(journal) = self.journal.take() {
            journal(outcome);
        }
    }
}

impl Drop for Observer {
    fn drop(&mut self) {
        let outcome = match self.answer.try_recv() {
            Ok(result) => outcome_of(&result),
            Err(_) => Outcome::Err(moli_i18n::tr!("serveur.journal.inconnu")),
        };
        self.write(outcome);
    }
}

/// An order in a driver's queue, and its journal line still to write. Its
/// caller may give up (a client gone, a cancelled task): if the order was
/// still queued, it is given up with it and never runs; if the driver had
/// taken it, the driver sees the caller gone before sending it, and the
/// outcome is still awaited and journaled. Either way, one line.
struct Delivery {
    observer: Option<Observer>,
    claim: Arc<AtomicU8>,
}

impl Delivery {
    async fn outcome(mut self) -> Result<(), CommandError> {
        let Some(observer) = self.observer.as_mut() else {
            return Err(CommandError::DriverUnavailable);
        };
        let result = answer_of(&mut observer.answer, observer.deadline).await;
        if let Some(mut observer) = self.observer.take() {
            observer.write(outcome_of(&result));
        }
        result
    }
}

impl Drop for Delivery {
    fn drop(&mut self) {
        let Some(mut observer) = self.observer.take() else {
            return;
        };
        if Claim::settle(&self.claim, Claim::GIVEN_UP) {
            observer.write(Outcome::Err(moli_i18n::tr!("serveur.journal.abandonne")));
            return;
        }
        // Taken by the driver: not sent yet, it will see the caller gone;
        // sent, it may already have acted. Its outcome is journaled.
        Claim::leave(&self.claim);
        if let Ok(runtime) = tokio::runtime::Handle::try_current() {
            runtime.spawn(observer.finish());
        }
        // No runtime: the observer's drop writes what is known.
    }
}

/// Cheap, clonable handle to the hub.
#[derive(Clone, Debug)]
pub struct Hub(Arc<Inner>);

#[derive(Debug)]
struct Inner {
    model: RwLock<Model>,
    journal: Mutex<Journal>,
    keypad: crate::keypad::Inputs,
    approvals: Mutex<Approvals>,
    events: broadcast::Sender<Event>,
    /// Counts emissions in exactly the broadcast order. Also gates an
    /// ordered subscription so its first event cannot fall in a gap.
    event_position: Mutex<u64>,
    occurrence_stream: crate::occurrences::Stream,
    buttons: tokio::sync::Mutex<crate::occurrences::Buttons>,
    counters: tokio::sync::Mutex<crate::counters::Counters>,
    timers: tokio::sync::Mutex<crate::timers::Timers>,
    timer_notify: tokio::sync::Notify,
    timer_consumer_ready: AtomicBool,
    timer_audience: RwLock<BTreeMap<PointId, Vec<moli_core::TimerRecipient>>>,
    temporals: tokio::sync::Mutex<crate::temporal::Temporals>,
    dependencies: tokio::sync::Mutex<crate::dependencies::Dependencies>,
    computed: crate::computed::Computed,
    durations: crate::durations::Durations,
    computed_wake: Arc<tokio::sync::Notify>,
    computed_started: AtomicBool,
    scenes: Mutex<crate::scenes::Scenes>,
    scenes_active: AtomicBool,
    scene_leases_active: AtomicBool,
    scene_sends: std::sync::OnceLock<Arc<tokio::sync::Semaphore>>,
    definition_gate: Arc<tokio::sync::Mutex<()>>,
    dependency_wake: Arc<tokio::sync::Notify>,
    dependency_started: AtomicBool,
    dependency_consumer_source: RwLock<Option<Arc<dyn crate::DependencyConsumerSource>>>,
    dependency_consumers:
        RwLock<BTreeMap<moli_core::DependencyRef, Vec<crate::DependencyConsumer>>>,
    /// Serializes label writes so the file always matches the model.
    label_write: tokio::sync::Mutex<()>,
    /// Where each instance last reached its device.
    addresses: Mutex<addresses::Book>,
    /// Serializes address writes so the file always matches the book.
    address_write: tokio::sync::Mutex<()>,
    journal_log: Option<JournalLog>,
    secrets: Option<SecretStore>,
    /// Why there is no secret store, in words a human can act on.
    secrets_problem: Option<String>,
    /// Values changed since the state cache was last written.
    state_dirty: AtomicBool,
    /// The last image of each camera, shared by every viewer for a second.
    images: Mutex<HashMap<DeviceId, LastImage>>,
    /// Short-lived media a device fetches back (an announcement's sound).
    published: Mutex<HashMap<String, (Instant, crate::media::Image)>>,
    /// The assistant voice satellites talk to (set after the drivers start).
    voice: std::sync::OnceLock<Arc<dyn crate::voice::VoiceBrain>>,
    opts: HubOptions,
    started: Instant,
}

impl Drop for Inner {
    fn drop(&mut self) {
        // The clock owns only a weak hub; wake it so dropping a hub frees its task.
        self.dependency_wake.notify_one();
        self.computed_wake.notify_one();
    }
}

/// Two screens showing the same camera live cost one fetch, not two.
const IMAGE_FRESH: Duration = Duration::from_secs(1);

/// How long a published media stays reachable, and how many at most.
const PUBLISHED_TTL: Duration = Duration::from_secs(5 * 60);
/// (A spoken announcement weighs ~2 MB, 8 MiB at most: 32 MiB at worst.)
const MAX_PUBLISHED: usize = 4;

/// A camera's last image and when it was taken; its viewers wait on this lock.
type LastImage = Arc<tokio::sync::Mutex<Option<(Instant, crate::media::Image)>>>;

#[derive(Debug, Default)]
struct Model {
    devices: BTreeMap<DeviceId, Arc<Device>>,
    states: States,
    /// Cached values not yet claimed by a device (its driver has not
    /// published it yet in this run).
    restored: States,
    availability: HashMap<DeviceId, bool>,
    /// Devices taken offline because their driver failed, with what they
    /// were before: given back when the driver runs again, unless it said
    /// something itself in between (a group that nothing ever re-announces
    /// must not stay offline forever).
    held_offline: HashMap<DeviceId, Option<bool>>,
    drivers: BTreeMap<InstanceId, DriverSlot>,
    labels: BTreeMap<DeviceId, Label>,
    reservations: crate::reservations::Book,
    snapshots: HashMap<DeviceId, Arc<dyn crate::media::SnapshotSource>>,
    printers: HashMap<DeviceId, Arc<dyn crate::media::PrintSink>>,
    dependency_heads: BTreeMap<moli_core::DependencyRef, u64>,
    scene_specs: BTreeMap<DeviceId, (moli_core::SceneSpec, crate::SceneScope)>,
}

#[derive(Debug)]
struct DriverSlot {
    kind: &'static str,
    integration: Arc<str>,
    status: DriverStatus,
    commands: mpsc::Sender<CommandRequest>,
}

#[derive(Debug)]
struct Journal {
    entries: VecDeque<Arc<JournalEntry>>,
    next_id: u64,
}

impl Hub {
    /// Creates a hub, loading persisted labels and cached values if configured.
    /// A corrupt state cache is discarded (it is only a cache); corrupt
    /// labels are an error (they are user data).
    pub fn new(opts: HubOptions) -> std::io::Result<Self> {
        let labels = match &opts.labels_path {
            Some(path) => labels::load(path)?,
            None => BTreeMap::new(),
        };
        let restored = match &opts.state_path {
            Some(path) => state_cache::load(path)?,
            None => States::new(),
        };
        let (journal_log, past) = match &opts.journal_path {
            Some(path) => {
                let (log, past) = JournalLog::open(path, opts.journal_capacity)?;
                (Some(log), past)
            }
            None => (None, Vec::new()),
        };
        let next_id = past.last().map_or(1, |e| e.id + 1);
        let book = opts
            .addresses_path
            .as_deref()
            .map(addresses::load)
            .unwrap_or_default();
        // An unreadable store (wrong or rotated master key, corrupt file)
        // must not take the whole home down: only drivers needing secrets
        // wait, and they say why.
        let (secrets, secrets_problem) = match &opts.secrets {
            Some((path, master)) => match secrets::master_key_bytes(master)
                .and_then(|key| SecretStore::open(path.clone(), &key))
            {
                Ok(store) => (Some(store), None),
                Err(e) => {
                    tracing::error!(error = %e, "secret store unavailable");
                    (
                        None,
                        Some(moli_i18n::tr!("serveur.coffre.illisible", error = e)),
                    )
                }
            },
            None => (None, Some(moli_i18n::tr!("serveur.coffre.cle_absente"))),
        };
        let (events, _) = broadcast::channel(opts.event_capacity.max(16));
        Ok(Self(Arc::new(Inner {
            model: RwLock::new(Model {
                restored,
                labels,
                ..Model::default()
            }),
            journal: Mutex::new(Journal {
                entries: past.into(),
                next_id,
            }),
            keypad: crate::keypad::Inputs::default(),
            approvals: Mutex::new(Approvals::default()),
            journal_log,
            secrets,
            secrets_problem,
            events,
            event_position: Mutex::new(0),
            occurrence_stream: crate::occurrences::Stream::default(),
            buttons: tokio::sync::Mutex::new(crate::occurrences::Buttons::new(
                opts.button_state_path.clone(),
            )),
            counters: tokio::sync::Mutex::new(crate::counters::Counters::new(
                opts.counter_state_path.clone(),
            )),
            timers: tokio::sync::Mutex::new(crate::timers::Timers::new(
                opts.timer_state_path.clone(),
            )),
            timer_notify: tokio::sync::Notify::new(),
            timer_consumer_ready: AtomicBool::new(false),
            timer_audience: RwLock::default(),
            temporals: tokio::sync::Mutex::new(crate::temporal::Temporals::new(
                opts.temporal_state_path.clone(),
            )),
            scenes: Mutex::default(),
            scenes_active: AtomicBool::new(false),
            scene_leases_active: AtomicBool::new(false),
            scene_sends: std::sync::OnceLock::new(),
            dependencies: tokio::sync::Mutex::new(crate::dependencies::Dependencies::new(
                opts.dependency_state_path.clone(),
            )),
            computed: crate::computed::Computed::default(),
            durations: crate::durations::Durations::new(opts.duration_state_path.clone()),
            computed_wake: Arc::new(tokio::sync::Notify::new()),
            computed_started: AtomicBool::new(false),
            definition_gate: Arc::new(tokio::sync::Mutex::new(())),
            dependency_wake: Arc::new(tokio::sync::Notify::new()),
            dependency_started: AtomicBool::new(false),
            dependency_consumer_source: RwLock::new(None),
            dependency_consumers: RwLock::new(BTreeMap::new()),
            label_write: tokio::sync::Mutex::new(()),
            addresses: Mutex::new(book),
            address_write: tokio::sync::Mutex::new(()),
            state_dirty: AtomicBool::new(false),
            images: Mutex::new(HashMap::new()),
            published: Mutex::new(HashMap::new()),
            voice: std::sync::OnceLock::new(),
            opts,
            started: Instant::now(),
        })))
    }

    /// The only trusted internal consumer; never exposed by REST/SSE/MCP.
    /// Dropping it discards pending inputs. Re-registration starts with an empty queue.
    pub fn take_keypad_inputs(&self) -> Option<crate::KeypadReceiver> {
        self.0.keypad.subscribe()
    }
    #[must_use]
    pub fn rejected_keypad_inputs(&self) -> u64 {
        self.0.keypad.rejected()
    }
    pub(crate) fn reject_keypad_input(&self) {
        self.0.keypad.reject();
    }
    pub(crate) fn submit_keypad_input(&self, input: crate::KeypadInput) -> bool {
        if input.action.is_empty()
            || input.action.len() > 64
            || input.action.chars().any(char::is_control)
            || input.device.as_str().len() > 512
            || self.device(&input.device).is_none()
        {
            self.0.keypad.reject();
            return false;
        }
        let device = input.device.clone();
        let accepted = self.0.keypad.send(input);
        if accepted {
            self.record(
                Origin::System,
                None,
                Action::KeypadInput { device },
                Outcome::Ok,
                Instant::now(),
            );
        }
        accepted
    }

    /// The assistant voice satellites talk to, once it exists (set once).
    pub fn set_voice_brain(&self, brain: Arc<dyn crate::voice::VoiceBrain>) {
        if self.0.voice.set(brain).is_err() {
            tracing::warn!("a voice brain was already set");
        }
    }

    /// The assistant, if the binary has handed it over yet.
    #[must_use]
    pub fn voice_brain(&self) -> Option<Arc<dyn crate::voice::VoiceBrain>> {
        self.0.voice.get().cloned()
    }

    // ---- reading -----------------------------------------------------------

    /// Subscribe to every subsequent event. Subscribe *before* taking a
    /// snapshot so nothing falls between the two.
    #[must_use]
    pub fn subscribe(&self) -> broadcast::Receiver<Event> {
        self.0.events.subscribe()
    }

    /// An ordinary subscription plus the position just before its first
    /// event. Advance by one on receipt, by `n` on `Lagged(n)`. Positions
    /// are local to this hub's lifetime, independent of wall-clock time.
    #[must_use]
    pub fn subscribe_with_position(&self) -> (broadcast::Receiver<Event>, u64) {
        let position = self
            .0
            .event_position
            .lock()
            .unwrap_or_else(PoisonError::into_inner);
        (self.0.events.subscribe(), *position)
    }

    /// The last event emitted, for consumers ordering an action against
    /// events not consumed yet. Their payload and public stream stay intact.
    #[must_use]
    pub fn event_position(&self) -> u64 {
        *self
            .0
            .event_position
            .lock()
            .unwrap_or_else(PoisonError::into_inner)
    }

    #[must_use]
    pub fn snapshot(&self) -> Snapshot {
        // Both take the model lock: never while holding it (a waiting
        // writer would deadlock a nested read).
        let guard = self.guard_status();
        let approvals = self.approvals();
        let model = self.read();
        Snapshot {
            devices: model.devices.values().map(|d| model.view(d)).collect(),
            drivers: model
                .drivers
                .iter()
                .map(|(instance, slot)| DriverView {
                    instance: instance.clone(),
                    kind: slot.kind,
                    integration: slot.integration.clone(),
                    status: slot.status.clone(),
                })
                .collect(),
            approvals,
            guard,
        }
    }

    #[must_use]
    pub fn device(&self, id: &DeviceId) -> Option<DeviceView> {
        let model = self.read();
        model.devices.get(id).map(|d| model.view(d))
    }

    /// A device's description and label, without copying its state: for
    /// callers after names and points only (the automation checker reads
    /// hundreds at each listing).
    #[must_use]
    pub fn describe(&self, id: &DeviceId) -> Option<(Arc<Device>, Label)> {
        let model = self.read();
        let device = model.devices.get(id)?;
        Some((
            Arc::clone(device),
            model.labels.get(id).cloned().unwrap_or_default(),
        ))
    }

    #[must_use]
    pub fn state(&self, point: &PointId) -> Option<Sample> {
        let (device, key) = point.split()?;
        self.read().states.get(&device)?.get(key).cloned()
    }

    /// Most recent journal entries first.
    #[must_use]
    pub fn journal(&self, limit: usize) -> Vec<Arc<JournalEntry>> {
        let journal = self
            .0
            .journal
            .lock()
            .unwrap_or_else(PoisonError::into_inner);
        journal.entries.iter().rev().take(limit).cloned().collect()
    }

    #[must_use]
    pub fn stats(&self) -> Stats {
        let model = self.read();
        Stats {
            uptime_ms: u64::try_from(self.0.started.elapsed().as_millis()).unwrap_or(u64::MAX),
            devices: model.devices.len(),
            points: model.devices.values().map(|d| d.points.len()).sum(),
            drivers: model.drivers.len(),
            drivers_running: model
                .drivers
                .values()
                .filter(|s| s.status == DriverStatus::Running)
                .count(),
            rss_bytes: crate::stats::rss_bytes(),
        }
    }

    // ---- writing (surfaces) --------------------------------------------------

    /// Validates a write, routes it to the owning driver, waits for its answer
    /// and journals the attempt — successful or not.
    pub async fn command(
        &self,
        point: &PointId,
        value: Value,
        origin: Origin,
        actor: Option<String>,
    ) -> Result<(), CommandError> {
        self.command_with_context(point, value, origin, actor, CommandContext::default())
            .await
    }

    /// Optional idempotency identity for an explicit button press.
    pub async fn command_with_request_id(
        &self,
        point: &PointId,
        value: Value,
        origin: Origin,
        actor: Option<String>,
        request_id: Option<String>,
    ) -> Result<(), CommandError> {
        self.command_with_context(
            point,
            value,
            origin,
            actor,
            CommandContext {
                request_id,
                ..CommandContext::default()
            },
        )
        .await
    }

    /// Carries an occurrence's correlation through an approved graph's actions.
    pub async fn command_correlated(
        &self,
        point: &PointId,
        value: Value,
        origin: Origin,
        actor: Option<String>,
        correlation: Option<String>,
    ) -> Result<(), CommandError> {
        self.command_with_context(
            point,
            value,
            origin,
            actor,
            CommandContext {
                correlation,
                ..CommandContext::default()
            },
        )
        .await
    }

    /// An order whose guest authorization must remain live until emission.
    pub async fn command_with_permit(
        &self,
        point: &PointId,
        value: Value,
        origin: Origin,
        actor: Option<String>,
        request_id: Option<String>,
        permit: crate::CommandPermit,
    ) -> Result<(), CommandError> {
        self.command_with_context(
            point,
            value,
            origin,
            actor,
            CommandContext {
                request_id,
                permit: Some(permit),
                ..CommandContext::default()
            },
        )
        .await
    }

    /// A correlated graph action whose authorization remains live until emission.
    pub async fn command_correlated_with_permit(
        &self,
        point: &PointId,
        value: Value,
        origin: Origin,
        actor: Option<String>,
        correlation: Option<String>,
        permit: crate::CommandPermit,
    ) -> Result<(), CommandError> {
        self.command_with_context(
            point,
            value,
            origin,
            actor,
            CommandContext {
                correlation,
                permit: Some(permit),
                ..CommandContext::default()
            },
        )
        .await
    }

    async fn command_with_context(
        &self,
        point: &PointId,
        value: Value,
        origin: Origin,
        actor: Option<String>,
        context: CommandContext,
    ) -> Result<(), CommandError> {
        let CommandContext {
            request_id,
            correlation,
            permit,
        } = context;
        let started = Instant::now();
        let actor = clean_actor(actor);
        if let Some(error) = command_input_error(point, &value) {
            let target = if error == CommandError::Invalid(ValueError::TooLong) {
                PointId::from(point.as_str().chars().take(MAX_POINT).collect::<String>())
            } else {
                point.clone()
            };
            self.record(
                origin,
                actor,
                Action::Command {
                    point: target,
                    value: Value::Null,
                },
                outcome_of(&Err(error.clone())),
                started,
            );
            return Err(error);
        }
        let mut journal_correlation = None;
        let prepared = if permit.as_ref().is_some_and(|permit| !permit.allows(point)) {
            Err(CommandError::AccessDenied)
        } else {
            self.prepare_context(
                point,
                &value,
                origin,
                actor.clone(),
                request_id,
                correlation,
            )
        };
        let result = match prepared {
            Err(e) => Err(e),
            Ok((prepared, metadata)) => {
                journal_correlation = metadata.correlation.clone();
                self.scene_order(&prepared.device, metadata.correlation.as_deref());
                match self.verdict(point, Some(&value), origin) {
                    Verdict::Allow => {
                        let hub = self.clone();
                        let action = Action::Command {
                            point: point.clone(),
                            value,
                        };
                        let correlation = metadata.correlation.clone();
                        return self
                            .send(
                                prepared,
                                Box::new(move |outcome| {
                                    hub.record_correlated(
                                        origin,
                                        actor,
                                        action,
                                        outcome,
                                        started,
                                        correlation,
                                    );
                                }),
                                metadata,
                                permit,
                            )
                            .await;
                    }
                    Verdict::Approval(reason) => {
                        let operation = prepared.is_operation();
                        let id = self.hold(
                            point,
                            prepared.approval_value(&value),
                            &metadata,
                            &reason,
                            operation,
                            permit,
                        )?;
                        Err(CommandError::NeedsApproval { id, reason })
                    }
                }
            }
        };
        let outcome = outcome_of(&result);
        self.record_correlated(
            origin,
            actor,
            Action::Command {
                point: point.clone(),
                value,
            },
            outcome,
            started,
            journal_correlation,
        );
        result
    }

    fn prepare_context(
        &self,
        point: &PointId,
        value: &Value,
        origin: Origin,
        actor: Option<String>,
        request_id: Option<String>,
        correlation: Option<String>,
    ) -> Result<(Prepared, CommandMetadata), CommandError> {
        use crate::OccurrenceError;
        let prepared = self.prepare(point, value)?;
        let request_id = request_id
            .map(|id| {
                id.parse::<moli_core::RequestId>()
                    .map_err(|_| OccurrenceError::RequestId)
            })
            .transpose()?;
        let operation = prepared
            .device
            .point(&prepared.key)
            .is_some_and(|point| point.kind.is_operation());
        if request_id.is_some() && !operation {
            return Err(OccurrenceError::Source.into());
        }
        if correlation.as_ref().is_some_and(|id| {
            id.parse::<moli_core::RequestId>().is_err()
                && !(id.len() == 32 && id.bytes().all(|byte| byte.is_ascii_hexdigit()))
        }) {
            return Err(OccurrenceError::RequestId.into());
        }
        let correlation = correlation.or_else(|| request_id.as_ref().map(ToString::to_string));
        let correlation = if operation && correlation.is_none() {
            Some(
                crate::occurrences::random_id()
                    .map_err(|_| OccurrenceError::Sequence)?
                    .to_string(),
            )
        } else {
            correlation
        };
        Ok((
            prepared,
            CommandMetadata {
                origin,
                actor,
                request_id,
                correlation,
            },
        ))
    }

    /// What the guard would say, now, about an order on this point from this
    /// origin: the reason it would be held, or `None` if it would go
    /// through. Nothing is sent. `value`: `None` when not known yet (a
    /// toggle), judged as the worst it could be.
    #[must_use]
    pub fn would_hold(
        &self,
        point: &PointId,
        value: Option<&Value>,
        origin: Origin,
    ) -> Option<String> {
        match self.verdict(point, value, origin) {
            Verdict::Allow => None,
            Verdict::Approval(reason) => Some(reason),
        }
    }

    /// What the guard says about an order on this point from this origin.
    fn verdict(&self, point: &PointId, value: Option<&Value>, origin: Origin) -> Verdict {
        // Stopping a machine at work (a print, a computer) and opening a
        // door are a person's call, whatever the room: an agent asks, and so
        // does the dashboard without a code.
        let agent = !matches!(origin, Origin::Ui | Origin::System | Origin::Automation);
        if agent && let Some(reason) = self.sensitive(point, value) {
            return Verdict::Approval(reason);
        }
        let rooms = point
            .split()
            .map(|(device, _)| self.rooms_of(&device))
            .unwrap_or_default();
        let rooms: Vec<&str> = rooms.iter().map(String::as_str).collect();
        self.0
            .opts
            .guard
            .check(&rooms, origin, jiff::Timestamp::now())
    }

    /// Why an order on this point is a person's call in any room: an order
    /// to a machine at work, or one that opens a door.
    fn sensitive(&self, point: &PointId, value: Option<&Value>) -> Option<String> {
        let (device, key) = point.split()?;
        let model = self.read();
        let spec = model.devices.get(&device).and_then(|d| d.point(key))?;
        if spec.semantic == moli_core::Semantic::Control {
            Some(moli_i18n::tr!("serveur.garde.machine"))
        } else if spec.opens(value) {
            Some(moli_i18n::tr!("serveur.garde.serrure"))
        } else {
            None
        }
    }

    /// Every room an order on this device reaches: its own (user label and
    /// source system's room) and, for a group, those of each member. All
    /// count for protection.
    #[must_use]
    pub fn rooms_of(&self, device: &DeviceId) -> Vec<String> {
        let model = self.read();
        let own = |id: &DeviceId| {
            let label = model.labels.get(id).and_then(|l| l.room.clone());
            let native = model
                .devices
                .get(id)
                .and_then(|d| d.native_room.as_deref().map(str::to_owned));
            label.into_iter().chain(native)
        };
        let members = model
            .devices
            .get(device)
            .map(|d| d.members.clone())
            .unwrap_or_default();
        let mut rooms: Vec<String> = own(device).chain(members.iter().flat_map(own)).collect();
        rooms.sort();
        rooms.dedup();
        rooms
    }

    /// Protected rooms that match no device's room: renamed in the source
    /// system? Then protection silently stopped applying — say so.
    #[must_use]
    pub fn unmatched_protected_rooms(&self) -> Vec<String> {
        let known: Vec<String> = {
            let model = self.read();
            model
                .labels
                .values()
                .filter_map(|l| l.room.clone())
                .chain(
                    model
                        .devices
                        .values()
                        .filter_map(|d| d.native_room.as_deref().map(str::to_owned)),
                )
                .collect()
        };
        let known: Vec<&str> = known.iter().map(String::as_str).collect();
        self.0
            .opts
            .guard
            .protected_rooms
            .iter()
            .filter(|p| !known.iter().any(|k| crate::guard::same_room(p, k)))
            .cloned()
            .collect()
    }

    /// Holds an order for a human; returns the request id.
    fn hold(
        &self,
        point: &PointId,
        value: &Value,
        metadata: &CommandMetadata,
        reason: &str,
        operation: bool,
        permit: Option<crate::CommandPermit>,
    ) -> Result<u64, CommandError> {
        let origin = metadata.origin;
        let actor = metadata.actor.clone();
        let now = now_ms();
        let (device_name, native_name, rooms) = point
            .split()
            .map(|(device, _)| {
                let (label, native) = {
                    let model = self.read();
                    let native = model
                        .devices
                        .get(&device)
                        .map_or_else(|| device.to_string(), |d| d.native_name.to_string());
                    let label = model.labels.get(&device).and_then(|l| l.name.clone());
                    (label, native)
                };
                (
                    label.unwrap_or_else(|| native.clone()),
                    native,
                    self.rooms_of(&device),
                )
            })
            .unwrap_or_default();
        let replaced;
        let request = {
            let mut approvals = self
                .0
                .approvals
                .lock()
                .unwrap_or_else(PoisonError::into_inner);
            if operation
                && let Some(key) = &metadata.request_id
                && let Some(existing) = approvals.pending.values().find(|request| {
                    &request.point == point
                        && request.origin == origin
                        && request.expires > now
                        && request.request_id.as_ref() == Some(key)
                })
            {
                if existing.value != *value {
                    return Err(crate::TimerError::Conflict.into());
                }
                return Ok(existing.id);
            }
            // Ids never repeat across restarts: a card left on a screen can
            // never approve a different, newer request.
            approvals.next_id = approvals.next_id.max(now).saturating_add(1);
            // A newer request for the same point, from the same origin,
            // replaces the older one; past the cap, the oldest gives way.
            let mut superseded: Vec<Arc<ApprovalRequest>> = approvals
                .pending
                .values()
                .filter(|r| !operation && &r.point == point && r.origin == origin)
                .cloned()
                .collect();
            for r in &superseded {
                approvals.pending.remove(&r.id);
                approvals.permits.remove(&r.id);
            }
            while approvals.pending.len() >= MAX_PENDING {
                let Some((&oldest, _)) = approvals.pending.iter().next() else {
                    break;
                };
                approvals.permits.remove(&oldest);
                if let Some(r) = approvals.pending.remove(&oldest) {
                    superseded.push(r);
                }
            }
            replaced = superseded;
            let request = Arc::new(ApprovalRequest {
                id: approvals.next_id,
                ts: now,
                expires: now + APPROVAL_TTL_MS,
                point: point.clone(),
                value: value.clone(),
                origin,
                actor,
                reason: reason.to_owned(),
                device_name,
                native_name,
                rooms,
                request_id: metadata.request_id.clone(),
                correlation: metadata.correlation.clone(),
            });
            if let Some(permit) = permit {
                approvals.permits.insert(request.id, permit);
            }
            approvals.pending.insert(request.id, Arc::clone(&request));
            request
        };
        let id = Ok(request.id);
        for old in replaced {
            self.resolved(
                &old,
                Decision::Expired,
                Origin::System,
                None,
                Outcome::Err(moli_i18n::tr!("serveur.garde.remplacee")),
                Instant::now(),
            );
        }
        self.emit(Event::ApprovalRequested { request });
        id
    }

    /// Orders waiting for a human, oldest first.
    #[must_use]
    pub fn approvals(&self) -> Vec<Arc<ApprovalRequest>> {
        self.0
            .approvals
            .lock()
            .unwrap_or_else(PoisonError::into_inner)
            .pending
            .values()
            .cloned()
            .collect()
    }

    /// A human approves (the order runs now) or denies a held order.
    /// Only the dashboard (`Origin::Ui`) may decide, and it must name the
    /// point it saw: a decision never lands on a request it did not show.
    pub async fn resolve_approval(
        &self,
        id: u64,
        expected_point: &PointId,
        approve: bool,
        origin: Origin,
        actor: Option<String>,
    ) -> Result<(), ApprovalError> {
        if origin != Origin::Ui {
            return Err(ApprovalError::HumanOnly);
        }
        let started = Instant::now();
        let (request, permit) = {
            let mut approvals = self
                .0
                .approvals
                .lock()
                .unwrap_or_else(PoisonError::into_inner);
            let request = match approvals.pending.get(&id) {
                None => return Err(ApprovalError::Unknown),
                Some(r) if &r.point != expected_point => return Err(ApprovalError::Mismatch),
                Some(_) => approvals
                    .pending
                    .remove(&id)
                    .ok_or(ApprovalError::Unknown)?,
            };
            (request, approvals.permits.remove(&id))
        };
        if request.expires <= now_ms() {
            self.resolved(
                &request,
                Decision::Expired,
                Origin::System,
                None,
                Outcome::Err(moli_i18n::tr!("serveur.garde.expiree")),
                started,
            );
            return Err(ApprovalError::Expired);
        }
        if !approve {
            self.resolved(
                &request,
                Decision::Denied,
                origin,
                actor,
                Outcome::Ok,
                started,
            );
            return Ok(());
        }
        let prepared = match self.prepare(&request.point, &request.value) {
            Ok(prepared) => prepared,
            Err(e) => {
                let outcome = Outcome::Err(e.to_string());
                self.resolved(
                    &request,
                    Decision::Approved,
                    origin,
                    actor,
                    outcome,
                    started,
                );
                return Err(ApprovalError::Command(e));
            }
        };
        // Like a command: one journal line, whatever becomes of the caller.
        let hub = self.clone();
        let metadata = CommandMetadata {
            origin: request.origin,
            actor: request.actor.clone(),
            request_id: request.request_id.clone(),
            correlation: request.correlation.clone(),
        };
        self.send(
            prepared,
            Box::new(move |outcome| {
                hub.resolved(
                    &request,
                    Decision::Approved,
                    origin,
                    actor,
                    outcome,
                    started,
                );
            }),
            metadata,
            permit,
        )
        .await
        .map_err(ApprovalError::Command)
    }

    /// Drops held orders nobody decided on in time.
    pub fn expire_approvals(&self) {
        let now = now_ms();
        let expired: Vec<_> = {
            let mut approvals = self
                .0
                .approvals
                .lock()
                .unwrap_or_else(PoisonError::into_inner);
            let ids: Vec<u64> = approvals
                .pending
                .values()
                .filter(|r| r.expires <= now)
                .map(|r| r.id)
                .collect();
            for id in &ids {
                approvals.permits.remove(id);
            }
            ids.iter()
                .filter_map(|id| approvals.pending.remove(id))
                .collect()
        };
        for request in expired {
            let outcome = Outcome::Err(moli_i18n::tr!("serveur.garde.expiree_sans_decision"));
            self.resolved(
                &request,
                Decision::Expired,
                Origin::System,
                None,
                outcome,
                Instant::now(),
            );
        }
    }

    fn resolved(
        &self,
        request: &ApprovalRequest,
        decision: Decision,
        origin: Origin,
        actor: Option<String>,
        outcome: Outcome,
        started: Instant,
    ) {
        self.emit(Event::ApprovalResolved {
            id: request.id,
            decision,
        });
        let action = Action::Approval {
            request: request.id,
            point: request.point.clone(),
            value: request.value.clone(),
            decision,
        };
        self.record_correlated(
            origin,
            actor,
            action,
            outcome,
            started,
            request.correlation.clone(),
        );
    }

    /// Journals a change to an automation (they live in their own crate;
    /// the audit trail is one).
    pub fn record_automation(
        &self,
        origin: Origin,
        actor: Option<String>,
        id: &str,
        name: &str,
        change: moli_core::AutomationChange,
        fingerprint: Option<String>,
    ) {
        self.record(
            origin,
            actor,
            Action::Automation {
                id: id.to_owned(),
                name: name.to_owned(),
                change,
                fingerprint,
            },
            Outcome::Ok,
            Instant::now(),
        );
    }

    /// Where `instance` last reached its device.
    #[must_use]
    pub fn known_address(&self, instance: &InstanceId) -> Option<KnownAddress> {
        self.0
            .addresses
            .lock()
            .unwrap_or_else(PoisonError::into_inner)
            .get(instance)
            .cloned()
    }

    /// Remembers where `instance` reached its device: written only when it
    /// changed (a driver says it at each start).
    pub async fn remember_address(
        &self,
        instance: &InstanceId,
        address: KnownAddress,
    ) -> std::io::Result<()> {
        let _write = self.0.address_write.lock().await;
        let book = {
            let mut book = self
                .0
                .addresses
                .lock()
                .unwrap_or_else(PoisonError::into_inner);
            let address = address.bounded();
            if book.get(instance) == Some(&address) {
                return Ok(());
            }
            book.insert(instance.clone(), address);
            book.clone()
        };
        match &self.0.opts.addresses_path {
            Some(path) => addresses::save(path, &book).await,
            None => Ok(()),
        }
    }

    /// Journals that `instance` found its device at another address.
    pub fn record_address(
        &self,
        instance: &InstanceId,
        device: Option<DeviceId>,
        from: &str,
        to: &str,
    ) {
        self.record(
            Origin::System,
            None,
            Action::Address {
                instance: instance.clone(),
                device,
                from: from.to_owned(),
                to: to.to_owned(),
            },
            Outcome::Ok,
            Instant::now(),
        );
    }

    /// Every writable point with this key (`announce`…), without copying
    /// the model: cheap enough for a check run on every automation.
    #[must_use]
    pub fn writable_points(&self, key: &str) -> Vec<PointId> {
        self.read()
            .devices
            .values()
            .filter(|d| d.point(key).is_some_and(|p| p.access.write))
            .map(|d| PointId::new(&d.id, key))
            .collect()
    }

    /// Publishes a short media for a device to fetch back (Sonos plays an
    /// announcement from a URL): reachable under an unguessable name for a
    /// few minutes, then gone. Returns the name (`<128 random bits>.<ext>`).
    pub fn publish_media(&self, extension: &str, image: crate::media::Image) -> Option<String> {
        use ring::rand::SecureRandom as _;
        let mut raw = [0u8; 16];
        // The name is the only key to it: never a guessable one.
        ring::rand::SystemRandom::new().fill(&mut raw).ok()?;
        let mut name = raw.iter().fold(String::with_capacity(40), |mut name, b| {
            use std::fmt::Write as _;
            let _ = write!(name, "{b:02x}");
            name
        });
        name.push('.');
        name.push_str(extension);
        let mut published = self
            .0
            .published
            .lock()
            .unwrap_or_else(PoisonError::into_inner);
        published.retain(|_, (at, _)| at.elapsed() < PUBLISHED_TTL);
        while published.len() >= MAX_PUBLISHED {
            let Some(oldest) = published
                .iter()
                .min_by_key(|(_, (at, _))| *at)
                .map(|(k, _)| k.clone())
            else {
                break;
            };
            published.remove(&oldest);
        }
        published.insert(name.clone(), (Instant::now(), image));
        Some(name)
    }

    /// A media published a few minutes ago, by its name.
    #[must_use]
    pub fn published_media(&self, name: &str) -> Option<crate::media::Image> {
        self.0
            .published
            .lock()
            .unwrap_or_else(PoisonError::into_inner)
            .get(name)
            .filter(|(at, _)| at.elapsed() < PUBLISHED_TTL)
            .map(|(_, image)| image.clone())
    }

    /// Journal entries that could not be written to disk since the start.
    #[must_use]
    pub fn journal_failures(&self) -> u64 {
        self.0.journal_log.as_ref().map_or(0, JournalLog::failures)
    }

    /// How the dashboard is recognized as the household.
    #[must_use]
    pub fn dashboard(&self) -> crate::guard::Dashboard {
        self.0.opts.guard.dashboard
    }

    #[must_use]
    pub fn guard_status(&self) -> GuardStatus {
        let mut status = self.0.opts.guard.status(jiff::Timestamp::now());
        status.unmatched_protected_rooms = self.unmatched_protected_rooms();
        status
    }

    /// Updates the user label of a device. Each field of the patch is
    /// independent: `None` keeps the current value, an empty string clears
    /// it. Merging happens under the label lock, so concurrent patches of
    /// different fields never overwrite each other.
    pub async fn set_label(
        &self,
        device: &DeviceId,
        patch: LabelPatch,
        origin: Origin,
        actor: Option<String>,
    ) -> Result<Label, LabelError> {
        let started = Instant::now();
        let result = match self.label_verdict(device, &patch, origin) {
            Some(reason) => Err(LabelError::Guarded(reason)),
            None => self.write_label(device, patch).await,
        };
        let outcome = match &result {
            Ok(_) => Outcome::Ok,
            Err(e) => Outcome::Err(e.to_string()),
        };
        let label = result.as_ref().ok().cloned().unwrap_or_default();
        self.record(
            origin,
            actor,
            Action::Label {
                device: device.clone(),
                label,
            },
            outcome,
            started,
        );
        result
    }

    /// Only a human may move a device out of (or between) protected rooms:
    /// otherwise an agent could relabel a bedroom lamp, then command it. The
    /// dashboard without a code names freely, but moves like an agent.
    fn label_verdict(
        &self,
        device: &DeviceId,
        patch: &LabelPatch,
        origin: Origin,
    ) -> Option<String> {
        if matches!(origin, Origin::Ui | Origin::System) {
            return None;
        }
        // An agent may name a device nobody named yet (onboarding), never
        // rename one: the sentence a person approves speaks of that name.
        if origin != Origin::Household
            && patch.name.is_some()
            && self
                .read()
                .labels
                .get(device)
                .is_some_and(|l| l.name.is_some())
        {
            return Some(moli_i18n::tr!("serveur.garde.renommer_humain"));
        }
        patch.room.as_ref()?;
        let rooms = self.rooms_of(device);
        let rooms: Vec<&str> = rooms.iter().map(String::as_str).collect();
        self.0
            .opts
            .guard
            .room_change_needs_human(&rooms)
            .map(|why| moli_i18n::tr!("serveur.garde.changer_piece_humain", why = why))
    }

    async fn write_label(&self, device: &DeviceId, patch: LabelPatch) -> Result<Label, LabelError> {
        let _guard = self.0.label_write.lock().await;
        let mut next = {
            let model = self.read();
            if !model.devices.contains_key(device) {
                return Err(LabelError::UnknownDevice);
            }
            model.labels.clone()
        };
        let label = patch.apply(next.get(device).cloned().unwrap_or_default());
        if label.is_empty() {
            next.remove(device);
        } else {
            next.insert(device.clone(), label.clone());
        }
        if let Some(path) = &self.0.opts.labels_path {
            labels::save(path, &next).await?;
        }
        {
            let mut model = self.write();
            self.scene_changed(device);
            model.labels = next;
        }
        self.emit(Event::LabelChanged {
            device: device.clone(),
            label: label.clone(),
        });
        Ok(label)
    }

    /// Resolves and validates an order without sending it.
    fn prepare(&self, point: &PointId, value: &Value) -> Result<Prepared, CommandError> {
        let (device_id, key) = point.split().ok_or(CommandError::UnknownPoint)?;
        let (device, key, kind, commands) = {
            let model = self.read();
            let device = model
                .devices
                .get(&device_id)
                .ok_or(CommandError::UnknownPoint)?;
            let spec = device.point(key).ok_or(CommandError::UnknownPoint)?;
            if matches!(
                spec.kind,
                moli_core::Kind::Schedule | moli_core::Kind::Computed
            ) {
                return Err(CommandError::ReadOnly);
            }
            if !spec.access.write {
                if matches!(spec.kind, moli_core::Kind::Counter { .. }) {
                    return Err(crate::CounterError::ReadOnly.into());
                }
                return Err(CommandError::ReadOnly);
            }
            let slot = model
                .drivers
                .get(&device.instance)
                .ok_or(CommandError::DriverUnavailable)?;
            (
                Arc::clone(device),
                spec.key.clone(),
                spec.kind.clone(),
                slot.commands.clone(),
            )
        };
        let value = if let moli_core::Kind::Temporal { spec } = &kind {
            crate::normalize_temporal(spec, value)?
        } else {
            validate(&kind, value).map_err(|error| {
                if matches!(kind, moli_core::Kind::TimerCommand { .. }) {
                    crate::TimerError::Value.into()
                } else if error == ValueError::ExpectedPress
                    && matches!(kind, moli_core::Kind::CounterCommand { .. })
                {
                    crate::CounterError::Value.into()
                } else if error == ValueError::ExpectedPress {
                    crate::OccurrenceError::Value.into()
                } else {
                    CommandError::Invalid(error)
                }
            })?
        };
        Ok(Prepared {
            point: point.clone(),
            device,
            key,
            value,
            commands,
        })
    }

    /// Hands a prepared order to its driver, waits for the answer, and has
    /// `journal` write its line (see [`Delivery`]).
    async fn send(
        &self,
        prepared: Prepared,
        journal: JournalLine,
        metadata: CommandMetadata,
        permit: Option<crate::CommandPermit>,
    ) -> Result<(), CommandError> {
        if permit
            .as_ref()
            .is_some_and(|permit| !permit.allows(&prepared.point))
        {
            let error = CommandError::AccessDenied;
            journal(outcome_of(&Err(error.clone())));
            return Err(error);
        }
        let Prepared {
            point,
            device,
            key,
            value,
            commands,
        } = prepared;
        let (reply, answer) = oneshot::channel();
        let claim = Arc::new(AtomicU8::new(Claim::QUEUED));
        let deadline = Instant::now() + self.0.opts.command_timeout;
        let queued = commands.try_send(CommandRequest {
            point,
            device,
            key,
            value,
            deadline,
            metadata,
            permit,
            reply: Arc::new(Mutex::new(Some(reply))),
            claim: Arc::clone(&claim),
        });
        if let Err(e) = queued {
            let error = match e {
                mpsc::error::TrySendError::Full(_) => CommandError::Busy,
                mpsc::error::TrySendError::Closed(_) => CommandError::DriverUnavailable,
            };
            journal(outcome_of(&Err(error.clone())));
            return Err(error);
        }
        Delivery {
            observer: Some(Observer {
                answer,
                deadline,
                journal: Some(journal),
            }),
            claim,
        }
        .outcome()
        .await
    }

    fn record(
        &self,
        origin: Origin,
        actor: Option<String>,
        action: Action,
        outcome: Outcome,
        started: Instant,
    ) {
        self.record_correlated(origin, actor, action, outcome, started, None);
    }

    fn record_correlated(
        &self,
        origin: Origin,
        actor: Option<String>,
        action: Action,
        outcome: Outcome,
        started: Instant,
        correlation: Option<String>,
    ) {
        let actor = clean_actor(actor);
        let entry = {
            let mut journal = self
                .0
                .journal
                .lock()
                .unwrap_or_else(PoisonError::into_inner);
            let entry = Arc::new(JournalEntry {
                id: journal.next_id,
                ts: now_ms(),
                origin,
                actor,
                action,
                outcome,
                duration_ms: u64::try_from(started.elapsed().as_millis()).unwrap_or(u64::MAX),
                correlation,
            });
            journal.next_id += 1;
            if journal.entries.len() == self.0.opts.journal_capacity {
                journal.entries.pop_front();
            }
            journal.entries.push_back(Arc::clone(&entry));
            entry
        };
        if let Some(log) = &self.0.journal_log {
            log.append(Arc::clone(&entry));
        }
        tracing::info!(id = entry.id, origin = ?entry.origin, outcome = ?entry.outcome, "journal");
        self.emit(Event::Journal { entry });
    }

    // ---- core secrets (the hub's own, e.g. human sessions) ------------------

    /// A secret of the hub itself (namespace `core`, reserved: no driver
    /// instance may be called that).
    #[must_use]
    pub fn core_secret(&self, name: &str) -> Option<String> {
        self.secret(&InstanceId::from(CORE_NAMESPACE), name)
    }

    pub async fn store_core_secret(&self, name: &str, value: &str) -> std::io::Result<()> {
        self.store_secret(&InstanceId::from(CORE_NAMESPACE), name, value)
            .await
    }

    /// Forgets a secret of the hub itself; `true` if it existed.
    pub async fn forget_core_secret(&self, name: &str) -> std::io::Result<bool> {
        self.forget_secret(&InstanceId::from(CORE_NAMESPACE), name)
            .await
    }

    // ---- secrets (drivers only, namespaced by instance) ----------------------

    /// Whether secrets can be kept (a master key was given).
    #[must_use]
    pub fn has_secret_store(&self) -> bool {
        self.0.secrets.is_some()
    }

    pub(crate) fn secrets_problem(&self) -> Option<&str> {
        self.0.secrets_problem.as_deref()
    }

    pub(crate) async fn forget_secret(
        &self,
        instance: &InstanceId,
        name: &str,
    ) -> std::io::Result<bool> {
        match &self.0.secrets {
            Some(store) => store.remove(&format!("{instance}/{name}")).await,
            None => Ok(false),
        }
    }

    /// A secret of a driver instance, or of a surface (the assistant's API
    /// key lives under `assistant/api_key`).
    #[must_use]
    pub fn secret(&self, instance: &InstanceId, name: &str) -> Option<String> {
        self.0.secrets.as_ref()?.get(&format!("{instance}/{name}"))
    }

    /// Files a secret for a driver instance: drivers through their context,
    /// surfaces when a person gives keys for an integration (never read
    /// back by them).
    pub async fn store_secret(
        &self,
        instance: &InstanceId,
        name: &str,
        value: &str,
    ) -> std::io::Result<()> {
        let store = self.0.secrets.as_ref().ok_or_else(|| {
            std::io::Error::other("no secret store: MOLI_MASTER_KEY is not configured")
        })?;
        store.set(&format!("{instance}/{name}"), value).await
    }

    /// A human-bound guest is admitted only by a current, live calendar snapshot.
    #[must_use]
    pub fn reservation_allows(&self, binding: &crate::ReservationRef) -> bool {
        let model = self.read();
        model
            .drivers
            .get(&binding.instance)
            .is_some_and(|slot| slot.kind == "reservations" && slot.status == DriverStatus::Running)
            && model.reservations.allows(binding, now_ms(), Instant::now())
    }

    pub(crate) fn replace_reservations(
        &self,
        instance: &InstanceId,
        windows: Vec<(String, moli_core::AccessWindow)>,
        expires: u64,
    ) -> bool {
        let mut model = self.write();
        if !model
            .drivers
            .get(instance)
            .is_some_and(|slot| slot.kind == "reservations" && slot.status == DriverStatus::Running)
        {
            model.reservations.remove(instance);
            return false;
        }
        model
            .reservations
            .replace(instance, windows, expires, now_ms(), Instant::now())
    }

    // ---- writing (drivers, via DriverCtx) -----------------------------------

    pub(crate) fn register_driver(
        &self,
        instance: &InstanceId,
        kind: &'static str,
        integration: Arc<str>,
    ) -> mpsc::Receiver<CommandRequest> {
        let (commands, rx) = mpsc::channel(COMMAND_QUEUE);
        let mut model = self.write();
        model.reservations.remove(instance);
        model.drivers.insert(
            instance.clone(),
            DriverSlot {
                kind,
                integration,
                status: DriverStatus::Starting,
                commands,
            },
        );
        drop(model);
        self.emit(Event::DriverStatus {
            instance: instance.clone(),
            status: DriverStatus::Starting,
        });
        rx
    }

    pub(crate) fn set_driver_status(&self, instance: &InstanceId, status: DriverStatus) {
        let (changed, back) = {
            let mut model = self.write();
            if status != DriverStatus::Running {
                model.reservations.remove(instance);
            }
            let changed = match model.drivers.get_mut(instance) {
                Some(slot) if slot.status != status => {
                    slot.status = status.clone();
                    true
                }
                _ => false,
            };
            let mut back = Vec::new();
            if changed && status == DriverStatus::Running {
                let held: Vec<DeviceId> = model
                    .held_offline
                    .keys()
                    .filter(|d| {
                        model
                            .devices
                            .get(*d)
                            .is_some_and(|d| &d.instance == instance)
                    })
                    .cloned()
                    .collect();
                for device in held {
                    let before = model.held_offline.remove(&device).flatten();
                    match before {
                        Some(online) => model.availability.insert(device.clone(), online),
                        None => model.availability.remove(&device),
                    };
                    back.push(device);
                }
            }
            (changed, back)
        };
        for device in back {
            self.emit(Event::Availability {
                device,
                online: true,
            });
        }
        if changed {
            self.emit(Event::DriverStatus {
                instance: instance.clone(),
                status,
            });
        }
    }

    pub(crate) fn upsert_device(&self, mut device: Device) {
        device
            .points
            .retain(|point| !moli_core::privacy::code_property(&point.key));
        let device = Arc::new(device);
        let restored = {
            let mut model = self.write();
            if model
                .devices
                .get(&device.id)
                .is_some_and(|d| **d == *device)
            {
                return;
            }
            // A number observed under the previous unit is not a measurement
            // under this descriptor, even before any calculation indexes it.
            // Invalidate at the model boundary, without tracking dormant sources
            // or renewing their age. No unit conversion can recover provenance.
            let changed_units: Vec<_> = device
                .points
                .iter()
                .filter(|point| {
                    point.kind.uses_state_cache()
                        && model
                            .devices
                            .get(&device.id)
                            .and_then(|before| before.point(&point.key))
                            .is_some_and(|before| before.unit != point.unit)
                })
                .map(|point| point.key.clone())
                .collect();
            self.scene_changed(&device.id);
            self.0.durations.invalidate(&device.id);
            // Claim cached values for the points this definition declares.
            // The rest stays cached: a device first published without its
            // definition (interview in progress) must not lose its history.
            let mut cached = model.restored.remove(&device.id).unwrap_or_default();
            let states = model.states.entry(device.id.clone()).or_default();
            states.retain(|key, _| {
                device
                    .point(key)
                    .is_some_and(|point| point.kind.uses_state_cache())
            });
            let mut restored = Vec::new();
            for key in changed_units {
                let discarded = cached.remove(&key).is_some();
                if let Some(sample) = states.get_mut(&key) {
                    if sample.value != Value::Null {
                        sample.value = Value::Null;
                        restored.push(Event::State {
                            point: PointId::new(&device.id, &key),
                            value: Value::Null,
                            ts: now_ms(),
                            source_ts: Some(sample.ts),
                        });
                    }
                    self.0.state_dirty.store(true, Ordering::Release);
                } else if discarded {
                    self.0.state_dirty.store(true, Ordering::Release);
                }
            }
            for point in &device.points {
                if !point.kind.uses_state_cache() {
                    if cached.remove(&point.key).is_some() {
                        self.0.state_dirty.store(true, Ordering::Release);
                    }
                    continue;
                }
                if let Some(sample) = cached.remove(&point.key)
                    && !states.contains_key(&point.key)
                {
                    restored.push(Event::State {
                        point: PointId::new(&device.id, &point.key),
                        value: sample.value.clone(),
                        ts: sample.ts,
                        source_ts: None,
                    });
                    states.insert(point.key.clone(), sample);
                }
            }
            if !cached.is_empty() {
                model.restored.insert(device.id.clone(), cached);
            }
            model.devices.insert(device.id.clone(), Arc::clone(&device));
            restored
        };
        self.emit(Event::DeviceUpserted { device });
        for event in restored {
            self.emit(event);
        }
    }

    /// Writes the state cache if anything changed since the last write.
    /// Returns whether a write happened.
    pub async fn persist_state(&self) -> std::io::Result<bool> {
        let Some(path) = &self.0.opts.state_path else {
            return Ok(false);
        };
        if !self.0.state_dirty.swap(false, Ordering::AcqRel) {
            return Ok(false);
        }
        let all = {
            let model = self.read();
            let mut all = model.restored.clone();
            all.extend(model.states.iter().map(|(k, v)| (k.clone(), v.clone())));
            for (device, samples) in &mut all {
                if let Some(definition) = model.devices.get(device) {
                    samples.retain(|key, _| {
                        definition
                            .point(key)
                            .is_none_or(|point| point.kind.uses_state_cache())
                    });
                }
            }
            all.retain(|_, samples| !samples.is_empty());
            all
        };
        if let Err(e) = state_cache::save(path, &all).await {
            self.0.state_dirty.store(true, Ordering::Release);
            return Err(e);
        }
        Ok(true)
    }

    pub(crate) fn remove_device(&self, id: &DeviceId) {
        self.remove_device_update(id, || {});
    }

    fn remove_device_update(&self, id: &DeviceId, after_invalidation: impl FnOnce()) {
        self.scene_changed(id);
        let removed = {
            let mut model = self.write();
            // Same model -> duration-book order as state capture. No producer
            // may reopen coverage between invalidation and removal.
            self.0.durations.invalidate(id);
            after_invalidation();
            model.states.remove(id);
            model.availability.remove(id);
            model.snapshots.remove(id);
            model.printers.remove(id);
            model.devices.remove(id).is_some()
        };
        self.0
            .images
            .lock()
            .unwrap_or_else(PoisonError::into_inner)
            .remove(id);
        if removed {
            self.emit(Event::DeviceRemoved { device: id.clone() });
        }
    }

    pub(crate) fn provide_snapshots(
        &self,
        device: &DeviceId,
        source: Arc<dyn crate::media::SnapshotSource>,
    ) {
        self.write().snapshots.insert(device.clone(), source);
    }

    pub(crate) fn provide_printing(
        &self,
        device: &DeviceId,
        sink: Arc<dyn crate::media::PrintSink>,
    ) {
        self.write().printers.insert(device.clone(), sink);
    }

    /// Hands a document to a printer (queued there: this returns once it is
    /// taken, not printed). The sink is called without the model lock.
    pub async fn print(
        &self,
        device: &DeviceId,
        document: crate::media::Document,
    ) -> Result<(), crate::media::PrintError> {
        use crate::media::PrintError;
        let sink = {
            let model = self.read();
            if !model.devices.contains_key(device) {
                return Err(PrintError::UnknownDevice);
            }
            model
                .printers
                .get(device)
                .cloned()
                .ok_or(PrintError::NotAPrinter)?
        };
        match tokio::time::timeout(std::time::Duration::from_secs(10), sink.print(document)).await {
            Ok(Ok(())) => Ok(()),
            Ok(Err(e)) => Err(PrintError::Refused(format!("{e:#}"))),
            Err(_) => Err(PrintError::Refused(moli_i18n::tr!(
                "serveur.impression.refusee"
            ))),
        }
    }

    /// A fresh image of a camera (at most a second old: viewers of the same
    /// camera share one fetch). The source is called without holding the
    /// model lock; viewers of one camera wait for the same fetch.
    pub async fn camera_image(
        &self,
        device: &DeviceId,
    ) -> Result<crate::media::Image, crate::media::SnapshotError> {
        use crate::media::SnapshotError;
        let source = {
            let model = self.read();
            if !model.devices.contains_key(device) {
                return Err(SnapshotError::UnknownDevice);
            }
            model
                .snapshots
                .get(device)
                .cloned()
                .ok_or(SnapshotError::NotACamera)?
        };
        let slot = Arc::clone(
            self.0
                .images
                .lock()
                .unwrap_or_else(PoisonError::into_inner)
                .entry(device.clone())
                .or_default(),
        );
        let mut last = slot.lock().await;
        if let Some((at, image)) = last.as_ref()
            && at.elapsed() < IMAGE_FRESH
        {
            return Ok(image.clone());
        }
        // Battery cameras wake up for an image: be patient.
        match tokio::time::timeout(std::time::Duration::from_secs(20), source.snapshot()).await {
            Ok(Ok(image)) => {
                *last = Some((Instant::now(), image.clone()));
                Ok(image)
            }
            Ok(Err(e)) => Err(SnapshotError::Failed(format!("{e:#}"))),
            Err(_) => Err(SnapshotError::Timeout),
        }
    }

    /// The protected room this device (or a member) is in, if any: images
    /// of it are for humans only. With `protect_unassigned`, a device in no
    /// room is protected too (as the guard does for commands).
    #[must_use]
    pub fn protected_room(&self, device: &DeviceId) -> Option<String> {
        let rooms = self.rooms_of(device);
        let rooms: Vec<&str> = rooms.iter().map(String::as_str).collect();
        let guard = &self.0.opts.guard;
        if let Some(room) = guard.protected(&rooms) {
            return Some(room.to_owned());
        }
        (guard.protect_unassigned && rooms.is_empty())
            .then(|| moli_i18n::tr!("serveur.garde.appareil_sans_piece"))
    }

    pub(crate) fn device_ids_of(&self, instance: &InstanceId) -> Vec<DeviceId> {
        self.read()
            .devices
            .values()
            .filter(|d| &d.instance == instance)
            .map(|d| d.id.clone())
            .collect()
    }

    /// Ids of the devices `instance` published, in this run or an earlier
    /// one (named, or with values kept from before the restart).
    pub(crate) fn known_device_ids_of(&self, instance: &InstanceId) -> Vec<DeviceId> {
        let model = self.read();
        let ids: std::collections::BTreeSet<&DeviceId> = model
            .devices
            .keys()
            .chain(model.labels.keys())
            .chain(model.restored.keys())
            .chain(model.states.keys())
            .filter(|id| &id.instance() == instance)
            .collect();
        ids.into_iter().cloned().collect()
    }

    /// Declared keys and cached keys not yet claimed by the driver. Values are
    /// deliberately not exposed: the next read must establish their freshness.
    pub(crate) fn known_point_keys(&self, device: &DeviceId) -> Vec<Arc<str>> {
        let model = self.read();
        let keys: std::collections::BTreeSet<&Arc<str>> = model
            .devices
            .get(device)
            .into_iter()
            .flat_map(|d| d.points.iter().map(|p| &p.key))
            .chain(model.states.get(device).into_iter().flat_map(|s| s.keys()))
            .chain(
                model
                    .restored
                    .get(device)
                    .into_iter()
                    .flat_map(|s| s.keys()),
            )
            .collect();
        keys.into_iter().cloned().collect()
    }

    /// Records a value. Unknown devices/points are ignored (the model only
    /// holds what drivers declared). Only actual changes are broadcast.
    pub(crate) fn set_state(&self, device: &DeviceId, key: &str, value: Value) {
        self.record_state(device, key, value, false);
    }

    /// Like `set_state`, but always broadcast: for points that are
    /// occurrences (button presses), where the same value twice is two events.
    pub(crate) fn pulse_state(&self, device: &DeviceId, key: &str, value: Value) {
        self.record_state(device, key, value, true);
    }

    fn record_state(&self, device: &DeviceId, key: &str, value: Value, always: bool) {
        self.record_state_update(device, key, value, always, |_| {});
    }

    fn record_state_update(
        &self,
        device: &DeviceId,
        key: &str,
        value: Value,
        always: bool,
        update: impl FnOnce(&mut Model),
    ) {
        if moli_core::privacy::code_property(key) || moli_core::privacy::private_value(&value) {
            return;
        }
        let pulse = always.then(|| value.clone());
        let observed_at = Instant::now();
        let scene_observed_at = self
            .0
            .scenes_active
            .load(Ordering::Acquire)
            .then_some(observed_at);
        let ts = now_ms();
        let event = {
            let mut model = self.write();
            let Some(spec) = model.devices.get(device).and_then(|d| d.point(key)) else {
                return;
            };
            let key = spec.key.clone();
            if self.0.durations.active.load(Ordering::Acquire) {
                self.0.durations.sample(
                    &PointId::new(device, &key),
                    &value,
                    spec,
                    model.availability.get(device) != Some(&false),
                    observed_at,
                    Some(observed_at),
                );
            }
            let cached = spec.kind.uses_state_cache();
            if spec.kind.is_operation() || spec.kind.is_occurrence() {
                let button = spec.kind == moli_core::Kind::Button;
                drop(model);
                if always && button {
                    let _ = self.publish_occurrence(device, &key, &value, None, None, false);
                }
                return;
            }
            let computed_active = self.0.computed.active();
            let unit = if computed_active {
                spec.unit.clone()
            } else {
                None
            };
            update(&mut model);
            if cached {
                self.0.state_dirty.store(true, Ordering::Release);
            }
            let states = model.states.entry(device.clone()).or_default();
            let changed = always || states.get(&key).is_none_or(|s| s.value != value);
            let event = changed.then(|| Event::State {
                point: PointId::new(device, &key),
                value: value.clone(),
                ts,
                source_ts: None,
            });
            if let Some(at) = scene_observed_at {
                self.scene_observe(&PointId::new(device, &key), &value, at);
            }
            states.insert(key.clone(), Sample { value, ts });
            if computed_active
                && self
                    .0
                    .computed
                    .sample(PointId::new(device, &key), ts, observed_at, unit)
            {
                self.0.computed_wake.notify_one();
            }
            event
        };
        if let Some(event) = event {
            self.emit(event);
        }
        if let Some(value) = pulse
            && let Err(error) = self.publish_occurrence(device, key, &value, None, None, false)
        {
            tracing::warn!(%error, %device, key, "occurrence was not published");
        }
    }

    #[must_use]
    pub fn occurrence_position(&self) -> u64 {
        self.0.occurrence_stream.position()
    }

    #[must_use]
    pub fn occurrence_stream(&self) -> Option<Arc<str>> {
        self.0.occurrence_stream.current()
    }

    /// A live occurrence was admitted but cannot be confirmed after an interruption.
    /// This audit record never republishes the occurrence or retries its actions.
    pub fn occurrence_problem(&self, event: &moli_core::Occurrence, message: String) {
        self.record_correlated(
            Origin::System,
            None,
            Action::Occurrence {
                point: event.point.clone(),
                occurrence: event.id.clone(),
                status: moli_core::OccurrenceStatus::Ambiguous,
            },
            Outcome::Err(message.clone()),
            Instant::now(),
            event.correlation.clone(),
        );
        self.notice(moli_core::Notice {
            title: None,
            message,
            from: None,
            ts: now_ms(),
        });
    }

    fn publish_occurrence(
        &self,
        device: &DeviceId,
        key: &str,
        value: &Value,
        identity: Option<moli_core::OccurrenceId>,
        correlation: Option<String>,
        durable: bool,
    ) -> Result<moli_core::Occurrence, crate::OccurrenceError> {
        let value = {
            let model = self.read();
            let spec = model
                .devices
                .get(device)
                .and_then(|d| d.point(key))
                .ok_or(crate::OccurrenceError::Source)?;
            validate(&spec.kind, value).map_err(|_| crate::OccurrenceError::Source)?
        };
        let occurrence = self
            .0
            .occurrence_stream
            .event(
                PointId::new(device, key),
                value,
                (self.0.opts.occurrence_clock)(),
                identity,
                correlation,
                durable,
            )
            .map_err(|error| {
                tracing::warn!(%error, "cannot allocate occurrence identity");
                crate::OccurrenceError::Sequence
            })?;
        self.emit(Event::Occurrence {
            occurrence: occurrence.clone(),
        });
        Ok(occurrence)
    }

    pub(crate) async fn initialize_counter(
        &self,
        device: &DeviceId,
        spec: moli_core::CounterSpec,
    ) -> Result<(), crate::CounterError> {
        let hub = self.clone();
        let device = device.clone();
        tokio::spawn(async move {
            let mut counters = hub.0.counters.lock().await;
            let value = counters.initialize(&device, spec).await?;
            hub.set_state(&device, "value", Value::Int(value));
            Ok(())
        })
        .await
        .map_err(|_| crate::CounterError::Uncertain)?
    }

    pub(crate) async fn counter_command(
        &self,
        command: CommandRequest,
        cancel: tokio_util::sync::CancellationToken,
    ) {
        let hub = self.clone();
        // Dropping this JoinHandle (driver stop or caller cancellation) does not
        // cancel a commit that has started. The task owns the reply and its audit.
        let task = tokio::spawn(async move {
            let result = hub.commit_counter(&command, &cancel).await;
            command.reply_result(result.map_err(CommandError::from));
        });
        let _ = task.await;
    }

    async fn commit_counter(
        &self,
        command: &CommandRequest,
        cancel: &tokio_util::sync::CancellationToken,
    ) -> Result<(), crate::CounterError> {
        use crate::CounterError;
        let Some(moli_core::PointSpec {
            kind: moli_core::Kind::CounterCommand { operation },
            ..
        }) = command.device.point(&command.key)
        else {
            return Err(CounterError::Definition);
        };
        let Some(moli_core::PointSpec {
            kind: moli_core::Kind::Counter { spec },
            ..
        }) = command.device.point("value")
        else {
            return Err(CounterError::Definition);
        };
        let key = match operation {
            moli_core::CounterOperation::Increment => "increment",
            moli_core::CounterOperation::Reset => "reset",
        };
        if command.value != Value::Null
            || command.key.as_ref() != key
            || command.point != PointId::new(&command.device.id, key)
        {
            return Err(CounterError::Definition);
        }
        let started = Instant::now();
        let mut counters = self.0.counters.lock().await;
        let result = counters
            .execute(
                &command.device.id,
                *spec,
                *operation,
                command.metadata.request_id.as_ref(),
                || command.abandoned() || cancel.is_cancelled(),
            )
            .await;
        let result = match result {
            Ok(commit) => {
                if let Some(value) = commit.change {
                    self.set_state(&command.device.id, "value", Value::Int(value));
                }
                commit.result
            }
            Err(error) => {
                if error == CounterError::Uncertain {
                    self.set_availability(&command.device.id, false);
                }
                Err(error)
            }
        };
        // Business outcomes follow the same order as commits, even when the
        // transport response or its observer has already disappeared.
        self.record_correlated(
            command.metadata.origin,
            command.metadata.actor.clone(),
            Action::Counter {
                point: command.point.clone(),
            },
            result
                .as_ref()
                .map_or_else(|error| Outcome::Err(error.to_string()), |()| Outcome::Ok),
            started,
            command.metadata.correlation.clone(),
        );
        drop(counters);
        result
    }

    pub(crate) async fn press_button(&self, command: &CommandRequest) -> Result<(), CommandError> {
        use crate::occurrences::{Dispatch, Reservation};
        use moli_core::OccurrenceStatus;
        if command
            .device
            .point(&command.key)
            .is_none_or(|p| p.kind != moli_core::Kind::Button)
            || command.value != Value::Null
        {
            return Err(crate::OccurrenceError::Source.into());
        }
        if command.abandoned() {
            return Err(CommandError::Timeout);
        }
        let started = Instant::now();
        let correlation = command
            .metadata
            .correlation
            .clone()
            .ok_or(crate::OccurrenceError::Source)?;
        let mut buttons = self.0.buttons.lock().await;
        let reservation = buttons
            .reserve(
                &command.point,
                command.metadata.request_id.as_ref(),
                &correlation,
            )
            .await?;
        let (receipt, status, result) = match reservation {
            Reservation::Duplicate(receipt) => {
                let result = if receipt.status == Dispatch::Published {
                    Ok(())
                } else {
                    Err(crate::OccurrenceError::Uncertain)
                };
                let status = if result.is_ok() {
                    OccurrenceStatus::Replayed
                } else {
                    OccurrenceStatus::Ambiguous
                };
                (receipt, status, result)
            }
            Reservation::New(receipt) => {
                let result = if command.abandoned() {
                    Err(crate::OccurrenceError::Uncertain)
                } else {
                    self.publish_occurrence(
                        &command.device.id,
                        &command.key,
                        &Value::Null,
                        Some(receipt.id.clone()),
                        Some(correlation.clone()),
                        buttons.file.is_persistent(),
                    )
                    .map(|_| ())
                };
                let result = match result {
                    Ok(()) => buttons
                        .published(&receipt.id)
                        .await
                        .map_err(|_| crate::OccurrenceError::Uncertain),
                    Err(error) => Err(error),
                };
                let status = if result.is_ok() {
                    OccurrenceStatus::Published
                } else {
                    OccurrenceStatus::Ambiguous
                };
                (receipt, status, result)
            }
        };
        self.record_correlated(
            command.metadata.origin,
            command.metadata.actor.clone(),
            Action::Occurrence {
                point: command.point.clone(),
                occurrence: receipt.id,
                status,
            },
            result
                .as_ref()
                .map_or_else(|error| Outcome::Err(error.to_string()), |()| Outcome::Ok),
            started,
            Some(receipt.correlation),
        );
        result.map_err(CommandError::from)
    }

    pub(crate) fn set_availability(&self, device: &DeviceId, online: bool) {
        let changed = {
            let mut model = self.write();
            if !model.devices.contains_key(device) {
                return;
            }
            // The driver speaks for it again.
            model.held_offline.remove(device);
            if !online {
                self.0.durations.invalidate(device);
            }
            model.availability.insert(device.clone(), online) != Some(online)
        };
        if changed {
            if !online {
                self.scene_changed(device);
            }
            self.emit(Event::Availability {
                device: device.clone(),
                online,
            });
        }
    }

    /// Every device of `instance` goes offline: its driver is down, its last
    /// values are no longer the truth (an automation must not act on them).
    pub(crate) fn mark_instance_offline(&self, instance: &InstanceId) {
        let gone: Vec<DeviceId> = {
            let mut model = self.write();
            let ids: Vec<DeviceId> = model
                .devices
                .values()
                .filter(|d| &d.instance == instance)
                .map(|d| d.id.clone())
                .collect();
            ids.into_iter()
                .filter(|id| {
                    self.0.durations.invalidate(id);
                    let before = model.availability.insert(id.clone(), false);
                    if before == Some(false) {
                        return false;
                    }
                    model.held_offline.entry(id.clone()).or_insert(before);
                    true
                })
                .collect()
        };
        for device in gone {
            self.emit(Event::Availability {
                device,
                online: false,
            });
        }
    }

    /// A message for the people at home, shown by the dashboards.
    pub fn notice(&self, notice: moli_core::Notice) {
        self.emit(Event::Notice { notice });
    }

    // ---- internals -----------------------------------------------------------

    fn emit(&self, event: Event) {
        let target = match &event {
            Event::Availability { device, .. } | Event::DeviceRemoved { device } => Some(device),
            Event::DeviceUpserted { device } => Some(&device.id),
            _ => None,
        };
        if let Some(device) = target
            && self
                .0
                .computed
                .device(device, matches!(event, Event::DeviceRemoved { .. }))
        {
            self.0.computed_wake.notify_one();
        }
        let mut position = self
            .0
            .event_position
            .lock()
            .unwrap_or_else(PoisonError::into_inner);
        *position = position.checked_add(1).expect("event position exhausted");
        // No subscriber is not an error.
        let _ = self.0.events.send(event);
    }

    fn read(&self) -> RwLockReadGuard<'_, Model> {
        self.0.model.read().unwrap_or_else(PoisonError::into_inner)
    }

    fn write(&self) -> RwLockWriteGuard<'_, Model> {
        self.0.model.write().unwrap_or_else(PoisonError::into_inner)
    }
}

impl Model {
    fn view(&self, device: &Arc<Device>) -> DeviceView {
        DeviceView {
            device: Arc::clone(device),
            label: self.labels.get(&device.id).cloned().unwrap_or_default(),
            online: self.availability.get(&device.id).copied(),
            state: self.states.get(&device.id).cloned().unwrap_or_default(),
            camera: self.snapshots.contains_key(&device.id),
            printer: self.printers.contains_key(&device.id),
        }
    }
}

#[cfg(test)]
mod reservation_admission_tests {
    use super::*;
    #[test]
    fn only_the_live_owning_calendar_can_admit_and_restarts_close_access() {
        let hub = Hub::new(HubOptions::default()).unwrap();
        let instance = InstanceId::from("fixture");
        let id = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
        let binding = crate::ReservationRef {
            instance: instance.clone(),
            id: id.into(),
        };
        let now = now_ms();
        let windows = || {
            vec![(
                id.into(),
                moli_core::AccessWindow::new(now - 1, now + 60_000).unwrap(),
            )]
        };
        let _rx = hub.register_driver(&instance, "reservations", "reservations".into());
        assert!(!hub.replace_reservations(&instance, windows(), now + 60_000));
        hub.set_driver_status(&instance, DriverStatus::Running);
        assert!(hub.replace_reservations(&instance, windows(), now + 60_000));
        assert!(hub.reservation_allows(&binding));
        hub.set_driver_status(
            &instance,
            DriverStatus::Waiting {
                reason: "simulated failure".into(),
            },
        );
        assert!(!hub.reservation_allows(&binding));
        hub.set_driver_status(&instance, DriverStatus::Running);
        assert!(!hub.reservation_allows(&binding));
        assert!(hub.replace_reservations(&instance, windows(), now + 60_000));
        let _rx = hub.register_driver(&instance, "reservations", "reservations".into());
        hub.set_driver_status(&instance, DriverStatus::Running);
        assert!(!hub.reservation_allows(&binding));
        let _rx = hub.register_driver(&instance, "fake", "fake".into());
        hub.set_driver_status(&instance, DriverStatus::Running);
        assert!(!hub.replace_reservations(&instance, windows(), now + 60_000));
    }
}

#[cfg(test)]
mod live_permit_tests {
    use super::*;
    fn target(semantic: moli_core::Semantic) -> (Hub, mpsc::Receiver<CommandRequest>, PointId) {
        let hub = Hub::new(HubOptions::default()).unwrap();
        let instance = InstanceId::from("fixture");
        let rx = hub.register_driver(&instance, "fake", "fake".into());
        let device = DeviceId::new(&instance, "lamp");
        hub.upsert_device(Device {
            id: device.clone(),
            instance,
            native_name: "simulated lamp".into(),
            manufacturer: None,
            model: None,
            description: None,
            native_room: None,
            members: Vec::new(),
            points: vec![moli_core::PointSpec {
                key: "state".into(),
                label: "state".into(),
                kind: moli_core::Kind::Binary,
                access: moli_core::Access {
                    read: true,
                    write: true,
                },
                unit: None,
                semantic,
            }],
        });
        (hub, rx, PointId::new(&device, "state"))
    }

    #[tokio::test]
    async fn auto_h1_r1_queued_or_taken_orders_observe_revocation_without_a_task_wakeup() {
        for taken in [false, true] {
            let (hub, mut rx, point) = target(moli_core::Semantic::OnOff);
            let allowed = Arc::new(AtomicBool::new(true));
            let check = allowed.clone();
            let h = hub.clone();
            let task = tokio::spawn(async move {
                h.command_with_permit(
                    &point,
                    Value::Bool(true),
                    Origin::Ui,
                    None,
                    None,
                    crate::CommandPermit::new(move |_point| check.load(Ordering::Acquire)),
                )
                .await
            });
            let cmd = rx.recv().await.unwrap();
            if taken {
                assert!(Claim::settle(&cmd.claim, Claim::TAKEN));
            }
            assert!(!cmd.abandoned());
            allowed.store(false, Ordering::Release);
            assert!(
                cmd.abandoned(),
                "revocation is checked after dequeue, before emission"
            );
            cmd.reply(Err("simulated revocation".into()));
            assert!(task.await.unwrap().is_err());
        }
    }
    #[tokio::test]
    async fn revocation_after_dequeue_still_prevents_emission() {
        let (hub, mut rx, point) = target(moli_core::Semantic::OnOff);
        let allowed = Arc::new(AtomicBool::new(true));
        let check = allowed.clone();
        let h = hub.clone();
        let task = tokio::spawn(async move {
            h.command_with_permit(
                &point,
                Value::Bool(true),
                Origin::Ui,
                None,
                None,
                crate::CommandPermit::new(move |_point| check.load(Ordering::Acquire)),
            )
            .await
        });
        let cmd = rx.recv().await.unwrap();
        assert!(Claim::settle(&cmd.claim, Claim::TAKEN));
        assert!(!cmd.abandoned());
        allowed.store(false, Ordering::Release);
        assert!(
            cmd.abandoned(),
            "revocation is checked after dequeue, before emission"
        );
        cmd.reply(Err("simulated revocation".into()));
        assert!(task.await.unwrap().is_err());
    }
    #[tokio::test]
    async fn an_approval_retains_live_admission_instead_of_reviving_an_expired_guest() {
        let (hub, mut rx, point) = target(moli_core::Semantic::Lock);
        let allowed = Arc::new(AtomicBool::new(true));
        let check = allowed.clone();
        let result = hub
            .command_with_permit(
                &point,
                Value::Bool(false),
                Origin::Api,
                None,
                None,
                crate::CommandPermit::new(move |_point| check.load(Ordering::Acquire)),
            )
            .await;
        let Err(CommandError::NeedsApproval { id, .. }) = result else {
            panic!("opening must be held by the lock guard");
        };
        allowed.store(false, Ordering::Release);
        let result = hub
            .resolve_approval(id, &point, true, Origin::Ui, None)
            .await;
        assert!(matches!(
            result,
            Err(ApprovalError::Command(CommandError::AccessDenied))
        ));
        assert!(rx.try_recv().is_err());
    }
}

#[cfg(test)]
mod schedule_timer_interop_tests {
    use super::*;
    use moli_core::{Access, Kind, PointSpec, Semantic, TimerField};

    #[test]
    fn schedule_projection_updates_never_turn_timer_expiry_into_a_cached_state() {
        let hub = Hub::new(HubOptions::default()).unwrap();
        let device = DeviceId::from("fixture:business");
        hub.upsert_device(Device {
            id: device.clone(),
            instance: "fixture".into(),
            native_name: "Synthetic business state".into(),
            manufacturer: None,
            model: None,
            description: None,
            native_room: None,
            members: vec![],
            points: [
                (
                    "finished",
                    Kind::Timer {
                        field: TimerField::Expired,
                    },
                ),
                ("active", Kind::Schedule),
            ]
            .into_iter()
            .map(|(key, kind)| PointSpec {
                key: key.into(),
                label: key.into(),
                kind,
                access: Access {
                    read: true,
                    write: false,
                },
                unit: None,
                semantic: Semantic::Other,
            })
            .collect(),
        });
        hub.record_state_update(&device, "finished", Value::Null, false, |_| {
            panic!("an occurrence must not enter projection updates");
        });
        assert!(hub.state(&PointId::new(&device, "finished")).is_none());
        let updated = AtomicBool::new(false);
        hub.record_state_update(&device, "active", Value::Bool(true), false, |_| {
            updated.store(true, Ordering::Release);
        });
        assert!(updated.load(Ordering::Acquire));
        assert_eq!(
            hub.state(&PointId::new(&device, "active")).unwrap().value,
            Value::Bool(true)
        );
    }
}
