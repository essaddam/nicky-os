//! The household's people: who lives here, what each may do, how each signs
//! in (« Personnes », like Home Assistant's persons and users).
//!
//! - `data/people.json` (written aside, then renamed; readable by Moli's user
//!   only, 0600 on unix): people, zones, pending invitations. Who lives here,
//!   their e-mails and places, but nothing that opens the house: a password
//!   lives in the encrypted store (`core/person/<id>/password`,
//!   PBKDF2-HMAC-SHA256), so do the sessions (their tokens as SHA-256 only);
//!   an invitation code is kept as an HMAC-SHA256 under a key of that store
//!   (`core/invite_key`), so the file alone cannot be tried against every
//!   code.
//! - Roles: `owner` (everything, manages people and the code), `member`
//!   (commands, approves automations with the code), `guest` (sees and
//!   commands its rooms only, until it expires: nothing of the rest of the
//!   house, nobody's whereabouts).
//! - Signing in: Cloudflare Access's verified e-mail names the person who has
//!   it (no password then); otherwise a password, from anywhere (a session
//!   bound to the person, not to an address: a phone changes address); a new
//!   person sets theirs with an invitation code.
//! - The e-mails of `[server.access] owners` become owners at the first start:
//!   a house that had owners keeps them, nothing to do.

use std::collections::{HashMap, HashSet};
use std::num::NonZeroU32;
use std::path::{Path, PathBuf};
use std::sync::{Mutex, PoisonError};

use axum::http::HeaderMap;
use axum::http::header::COOKIE;
use moli_core::{DeviceId, InstanceId, now_ms};
use moli_runtime::{Hub, Snapshot};
use ring::digest::{SHA256, digest};
use ring::rand::{SecureRandom, SystemRandom};
use ring::{hmac, pbkdf2};
use serde::{Deserialize, Serialize};

use crate::caller::Caller;
use crate::session::{LoginError, Sessions};

pub(crate) const FILE: &str = "people.json";
const COOKIE_NAME: &str = "moli_person";
const SESSIONS_KEY: &str = "person_sessions";
const SESSION_MAX_AGE_S: u64 = 30 * 24 * 3600;
const MAX_SESSIONS_PER_PERSON: usize = 10;
const MAX_PEOPLE: usize = 50;
const MAX_ZONES: usize = 50;
pub(crate) const MIN_PASSWORD: usize = 10;
const MAX_PASSWORD: usize = 200;
const INVITE_TTL_MS: u64 = 7 * 24 * 3600 * 1000;
/// An invitation code: letters none can misread, eight of them.
const INVITE_ALPHABET: &[u8] = b"ABCDEFGHJKMNPQRSTUVWXYZ23456789";
const INVITE_LEN: usize = 8;
/// The key invitation codes are kept under (encrypted store).
const INVITE_KEY: &str = "invite_key";
#[cfg(not(test))]
const PBKDF2_ROUNDS: u32 = 600_000;
#[cfg(test)]
const PBKDF2_ROUNDS: u32 = 1_000;
/// Drivers whose devices say where someone is (their phones, where each
/// person is, who is home): never a guest's, whatever their room.
const WHEREABOUTS: [&str; 3] = ["phones", "people", "presence"];

#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub(crate) enum Role {
    Owner,
    Member,
    Guest,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub(crate) struct Person {
    /// Stable: phones and automations name it. Never renamed.
    pub(crate) id: String,
    pub(crate) name: String,
    pub(crate) role: Role,
    /// E-mails Cloudflare Access may vouch for (lowercase).
    #[serde(default)]
    pub(crate) emails: Vec<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub(crate) color: Option<String>,
    /// A guest's rooms (the only ones it may command).
    #[serde(default)]
    pub(crate) rooms: Vec<String>,
    /// A guest's inclusive start (ms), independent of any calendar binding.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub(crate) starts: Option<u64>,
    /// A guest's end (ms): past it, the person may no longer sign in.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub(crate) expires: Option<u64>,
    /// Optional human-selected reservation. It grants nothing by itself.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub(crate) reservation: Option<moli_runtime::ReservationRef>,
    /// Wi-Fi addresses of devices that say the person is home.
    #[serde(default)]
    pub(crate) macs: Vec<String>,
    #[serde(default)]
    pub(crate) created: u64,
}

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub(crate) struct Zone {
    pub(crate) id: String,
    pub(crate) name: String,
    pub(crate) latitude: f64,
    pub(crate) longitude: f64,
    /// Metres.
    pub(crate) radius: f64,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub(crate) icon: Option<String>,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct Invite {
    /// HMAC-SHA256 of the code (hex), under the house's invitation key.
    #[serde(default)]
    code_hmac: String,
    /// What older versions kept: a bare SHA-256, which whoever read the
    /// file could try every code against. Such an invitation opens nothing:
    /// dropped when the file is read, the owner invites again.
    #[serde(default, skip_serializing)]
    code_sha256: Option<String>,
    person: String,
    expires: u64,
}

#[derive(Clone, Debug, Default, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub(crate) struct Book {
    #[serde(default)]
    pub(crate) people: Vec<Person>,
    #[serde(default)]
    pub(crate) zones: Vec<Zone>,
    #[serde(default)]
    invites: Vec<Invite>,
}

/// Who a request comes from, when it is a person.
#[derive(Clone, Debug, PartialEq, Eq, Serialize)]
pub(crate) struct PersonRef {
    pub(crate) id: String,
    pub(crate) name: String,
    pub(crate) role: Role,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(crate) starts: Option<u64>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub(crate) expires: Option<u64>,
    /// A guest's rooms.
    #[serde(skip_serializing_if = "Vec::is_empty")]
    pub(crate) rooms: Vec<String>,
}

impl PersonRef {
    pub(crate) fn is_owner(&self) -> bool {
        self.role == Role::Owner
    }

    pub(crate) fn is_guest(&self) -> bool {
        self.role == Role::Guest
    }

    /// What a guest sees of the house, and commands: the devices whose rooms
    /// are all its own (a group's members' count too; a device without a
    /// room is nobody's), never one that says where someone is.
    pub(crate) fn guest_devices(&self, hub: &Hub, snapshot: &Snapshot) -> HashSet<DeviceId> {
        let hidden = whereabouts(snapshot);
        snapshot
            .devices
            .iter()
            .map(|view| &view.device.id)
            .filter(|id| self.in_rooms(hub, &hidden, id))
            .cloned()
            .collect()
    }

    /// The house as this guest sees it (its devices, the orders held for
    /// them), and the devices it sees.
    pub(crate) fn guest_view(&self, hub: &Hub) -> (Snapshot, HashSet<DeviceId>) {
        let mut snapshot = hub.snapshot();
        let sight = self.guest_devices(hub, &snapshot);
        snapshot
            .devices
            .retain(|view| sight.contains(&view.device.id));
        snapshot
            .approvals
            .retain(|a| a.point.split().is_some_and(|(id, _)| sight.contains(&id)));
        (snapshot, sight)
    }

    /// Whether this guest sees (and commands) `device`.
    pub(crate) fn guest_sees(&self, hub: &Hub, device: &DeviceId) -> bool {
        let snapshot = hub.snapshot();
        snapshot
            .devices
            .iter()
            .any(|view| view.device.id == *device)
            && self.in_rooms(hub, &whereabouts(&snapshot), device)
    }

    fn in_rooms(&self, hub: &Hub, hidden: &HashSet<InstanceId>, device: &DeviceId) -> bool {
        if hidden.contains(&device.instance()) {
            return false;
        }
        let rooms = hub.rooms_of(device);
        !rooms.is_empty() && rooms.iter().all(|r| self.rooms.contains(r))
    }
}

/// The driver instances whose devices say where someone is.
fn whereabouts(snapshot: &Snapshot) -> HashSet<InstanceId> {
    snapshot
        .drivers
        .iter()
        .filter(|d| WHEREABOUTS.contains(&d.kind))
        .map(|d| d.instance.clone())
        .collect()
}

#[derive(Clone, Debug, Serialize, Deserialize)]
struct PersonSession {
    person: String,
    created: u64,
}

/// Why a change to the people was refused (a sentence for the person).
#[derive(Debug, PartialEq, Eq)]
pub(crate) enum Refused {
    Invalid(String),
    NotFound,
    LastOwner,
    Store,
}

pub(crate) struct People {
    hub: Hub,
    path: Option<PathBuf>,
    book: Mutex<Book>,
    sessions: Mutex<HashMap<String, PersonSession>>,
    write: tokio::sync::Mutex<()>,
    pub(crate) alarm_profiles: tokio::sync::Mutex<Option<moli_alarm_access::ProfileRevoker>>,
}

impl std::fmt::Debug for People {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("People")
            .field("people", &lock(&self.book).people.len())
            .finish_non_exhaustive()
    }
}

fn lock<T>(m: &Mutex<T>) -> std::sync::MutexGuard<'_, T> {
    m.lock().unwrap_or_else(PoisonError::into_inner)
}

fn hex(bytes: &[u8]) -> String {
    use std::fmt::Write as _;
    bytes.iter().fold(String::new(), |mut s, b| {
        let _ = write!(s, "{b:02x}");
        s
    })
}

fn unhex(s: &str) -> Option<Vec<u8>> {
    s.len()
        .is_multiple_of(2)
        .then(|| {
            (0..s.len())
                .step_by(2)
                .map(|i| u8::from_str_radix(s.get(i..i + 2)?, 16).ok())
                .collect()
        })
        .flatten()
}

fn hash(s: &str) -> String {
    hex(digest(&SHA256, s.as_bytes()).as_ref())
}

fn password_key(id: &str) -> String {
    format!("person/{id}/password")
}

/// `pbkdf2-sha256$<rounds>$<salt>$<hash>` (hex).
fn hash_password(password: &str) -> Option<String> {
    let mut salt = [0u8; 16];
    SystemRandom::new().fill(&mut salt).ok()?;
    let mut out = [0u8; 32];
    pbkdf2::derive(
        pbkdf2::PBKDF2_HMAC_SHA256,
        NonZeroU32::new(PBKDF2_ROUNDS)?,
        &salt,
        password.as_bytes(),
        &mut out,
    );
    Some(format!(
        "pbkdf2-sha256${PBKDF2_ROUNDS}${}${}",
        hex(&salt),
        hex(&out)
    ))
}

fn password_matches(stored: &str, attempt: &str) -> bool {
    let mut parts = stored.split('$');
    let (Some("pbkdf2-sha256"), Some(rounds), Some(salt), Some(expected)) =
        (parts.next(), parts.next(), parts.next(), parts.next())
    else {
        return false;
    };
    let (Some(rounds), Some(salt), Some(expected)) = (
        rounds.parse::<u32>().ok().and_then(NonZeroU32::new),
        unhex(salt),
        unhex(expected),
    ) else {
        return false;
    };
    pbkdf2::verify(
        pbkdf2::PBKDF2_HMAC_SHA256,
        rounds,
        &salt,
        attempt.as_bytes(),
        &expected,
    )
    .is_ok()
}

fn token() -> Option<String> {
    let mut raw = [0u8; 32];
    SystemRandom::new().fill(&mut raw).ok()?;
    Some(hex(&raw))
}

fn invite_code() -> Option<String> {
    let mut raw = [0u8; INVITE_LEN];
    SystemRandom::new().fill(&mut raw).ok()?;
    let letters: String = raw
        .iter()
        .map(|b| char::from(INVITE_ALPHABET[usize::from(*b) % INVITE_ALPHABET.len()]))
        .collect();
    Some(format!("{}-{}", &letters[..4], &letters[4..]))
}

/// What a person types, as compared: no spaces, no dash, capitals.
fn plain_code(code: &str) -> String {
    code.chars()
        .filter(char::is_ascii_alphanumeric)
        .map(|c| c.to_ascii_uppercase())
        .collect()
}

/// How an invitation code is kept: its HMAC-SHA256 under the house's key.
fn invite_digest(key: &hmac::Key, code: &str) -> String {
    hex(hmac::sign(key, plain_code(code).as_bytes()).as_ref())
}

/// `people.json` says who lives here, their e-mails and places: for Moli's
/// user alone (0600 on unix, like the secret store).
fn write_private(path: &Path, bytes: &[u8]) -> std::io::Result<()> {
    use std::io::Write as _;
    let mut options = std::fs::OpenOptions::new();
    options.write(true).create(true).truncate(true);
    #[cfg(unix)]
    std::os::unix::fs::OpenOptionsExt::mode(&mut options, 0o600);
    let mut file = options.open(path)?;
    // A file left there (a crash) kept its own mode.
    private(path)?;
    file.write_all(bytes)
}

#[cfg(unix)]
fn private(path: &Path) -> std::io::Result<()> {
    use std::os::unix::fs::PermissionsExt as _;
    std::fs::set_permissions(path, std::fs::Permissions::from_mode(0o600))
}

#[cfg(not(unix))]
#[allow(clippy::unnecessary_wraps)]
fn private(_: &Path) -> std::io::Result<()> {
    Ok(())
}

fn cookie_token(headers: &HeaderMap) -> Option<&str> {
    headers
        .get_all(COOKIE)
        .iter()
        .filter_map(|v| v.to_str().ok())
        .flat_map(|v| v.split(';'))
        .find_map(|kv| kv.trim().strip_prefix(COOKIE_NAME)?.strip_prefix('='))
}

/// An id from a name: `Élodie` → `elodie`.
pub(crate) fn slug(name: &str) -> String {
    let mut s = String::new();
    for c in name.trim().to_lowercase().chars() {
        let c = match c {
            'à' | 'â' | 'ä' | 'á' => 'a',
            'é' | 'è' | 'ê' | 'ë' => 'e',
            'î' | 'ï' | 'í' => 'i',
            'ô' | 'ö' | 'ó' => 'o',
            'ù' | 'û' | 'ü' | 'ú' => 'u',
            'ç' => 'c',
            'ñ' => 'n',
            c => c,
        };
        if c.is_ascii_alphanumeric() {
            s.push(c);
        } else if !s.ends_with('-') && !s.is_empty() {
            s.push('-');
        }
    }
    let s = s.trim_end_matches('-').chars().take(32).collect::<String>();
    if s.is_empty() { "personne".into() } else { s }
}

fn text_ok(s: &str, max: usize) -> bool {
    let s = s.trim();
    !s.is_empty() && s.chars().count() <= max && !s.chars().any(char::is_control)
}

fn invitation_person(book: &Book, code: &str, now: u64) -> Option<String> {
    book.invites
        .iter()
        .find(|invite| !code.is_empty() && invite.code_hmac == code && invite.expires > now)
        .and_then(|invite| {
            book.people
                .iter()
                .find(|person| person.id == invite.person && account_active_at(person, now))
        })
        .map(|person| person.id.clone())
}

fn account_active_at(person: &Person, now: u64) -> bool {
    person.starts.is_none_or(|start| start <= now) && person.expires.is_none_or(|end| now < end)
}

fn active(p: &Person, hub: &Hub) -> bool {
    account_active_at(p, now_ms())
        && (p.role != Role::Guest
            || p.reservation
                .as_ref()
                .is_none_or(|binding| hub.reservation_allows(binding)))
}

impl People {
    /// Reads `people.json` (none: nobody yet) and makes `owners` (Access
    /// e-mails of `[server.access]`) owners if nobody has their e-mail.
    pub(crate) fn open(hub: Hub, data_dir: Option<&Path>, owners: &[String]) -> Self {
        let path = data_dir.map(|d| d.join(FILE));
        let mut book: Book = path
            .as_deref()
            .and_then(|p| std::fs::read(p).ok())
            .and_then(|raw| match serde_json::from_slice(&raw) {
                Ok(book) => Some(book),
                Err(e) => {
                    tracing::error!(error = %e, "people.json unreadable: nobody is known until it is fixed");
                    None
                }
            })
            .unwrap_or_default();
        let mut changed = false;
        for email in owners {
            let email = email.trim().to_lowercase();
            if email.is_empty() || book.people.iter().any(|p| p.emails.contains(&email)) {
                continue;
            }
            let local = email.split('@').next().unwrap_or("proprietaire");
            let mut name: String = local.chars().take(30).collect();
            if let Some(first) = name.get(..1) {
                name = first.to_uppercase() + &name[1..];
            }
            let id = unique_id(&book, &slug(local));
            book.people.push(Person {
                id,
                name,
                role: Role::Owner,
                emails: vec![email],
                color: None,
                rooms: Vec::new(),
                starts: None,
                expires: None,
                reservation: None,
                macs: Vec::new(),
                created: now_ms(),
            });
            changed = true;
        }
        // Invitations of an older kind (a bare SHA-256) open nothing now.
        let invites = book.invites.len();
        book.invites
            .retain(|i| i.code_sha256.is_none() && !i.code_hmac.is_empty());
        if book.invites.len() < invites {
            tracing::warn!(
                dropped = invites - book.invites.len(),
                "pending invitations of an older kind dropped: invite again"
            );
            changed = true;
        }
        // Written by an older version, readable by all: Moli's user's only.
        if let Some(path) = path.as_deref().filter(|p| p.exists())
            && let Err(e) = private(path)
        {
            tracing::warn!(error = %e, "people.json left readable by others");
        }
        let sessions = hub
            .core_secret(SESSIONS_KEY)
            .and_then(|json| serde_json::from_str(&json).ok())
            .unwrap_or_default();
        let people = Self {
            hub,
            path,
            book: Mutex::new(book),
            sessions: Mutex::new(sessions),
            write: tokio::sync::Mutex::new(()),
            alarm_profiles: tokio::sync::Mutex::new(None),
        };
        if changed && let Err(e) = people.save_now() {
            tracing::error!(error = %e, "people.json not written");
        }
        people
    }

    fn save_now(&self) -> std::io::Result<()> {
        let Some(path) = &self.path else {
            return Ok(());
        };
        let json = serde_json::to_vec_pretty(&*lock(&self.book)).unwrap_or_default();
        let tmp = path.with_extension("json.tmp");
        write_private(&tmp, &json)?;
        std::fs::rename(&tmp, path)
    }

    async fn change<T>(
        &self,
        f: impl FnOnce(&mut Book) -> Result<T, Refused>,
    ) -> Result<T, Refused> {
        let _guard = self.write.lock().await;
        self.change_locked(f)
    }

    /// Caller holds `write`, including any alarm-profile revocation barrier.
    fn change_locked<T>(
        &self,
        f: impl FnOnce(&mut Book) -> Result<T, Refused>,
    ) -> Result<T, Refused> {
        let before = lock(&self.book).clone();
        let out = {
            let mut book = lock(&self.book);
            f(&mut book)?
        };
        if self.save_now().is_err() {
            *lock(&self.book) = before;
            return Err(Refused::Store);
        }
        Ok(out)
    }

    pub(crate) fn alarm_setup(&self) -> Option<(Hub, PathBuf)> {
        self.path
            .as_ref()?
            .parent()
            .map(|path| (self.hub.clone(), path.to_owned()))
    }

    pub(crate) fn alarm_person(&self, id: &str, now: u64) -> Option<moli_alarm_access::Person> {
        let book = lock(&self.book);
        let person = book.people.iter().find(|person| person.id == id)?;
        Some(moli_alarm_access::Person {
            guest: person.role == Role::Guest,
            from: person.starts,
            until: person.expires,
            reservation_active: person
                .reservation
                .as_ref()
                .is_none_or(|binding| self.hub.reservation_allows(binding))
                && account_active_at(person, now),
        })
    }

    pub(crate) fn book(&self) -> Book {
        lock(&self.book).clone()
    }

    /// Whether an owner can sign in (a password set, or an e-mail Access
    /// vouches for): until then, the house's code manages the people (else
    /// the first owner, created but not yet invited, could never be).
    pub(crate) fn has_owner(&self) -> bool {
        lock(&self.book).people.iter().any(|p| {
            p.role == Role::Owner
                && active(p, &self.hub)
                && (!p.emails.is_empty() || self.hub.core_secret(&password_key(&p.id)).is_some())
        })
    }

    fn reference(p: &Person) -> PersonRef {
        PersonRef {
            id: p.id.clone(),
            name: p.name.clone(),
            role: p.role,
            starts: p.starts,
            expires: p.expires,
            rooms: p.rooms.clone(),
        }
    }

    pub(crate) fn get(&self, id: &str) -> Option<PersonRef> {
        lock(&self.book)
            .people
            .iter()
            .find(|p| p.id == id && active(p, &self.hub))
            .map(Self::reference)
    }

    pub(crate) fn known_email(&self, email: &str) -> bool {
        let email = email.trim().to_lowercase();
        lock(&self.book)
            .people
            .iter()
            .any(|person| person.emails.contains(&email))
    }

    /// Weak capture: pending approvals cannot keep the hub and people alive in a cycle.
    pub(crate) fn command_permit(
        self: &std::sync::Arc<Self>,
        guest: &PersonRef,
    ) -> moli_runtime::CommandPermit {
        let people = std::sync::Arc::downgrade(self);
        let id = guest.id.clone();
        moli_runtime::CommandPermit::new(move |point| {
            let Some(people) = people.upgrade() else {
                return false;
            };
            let Some(current) = people.get(&id).filter(PersonRef::is_guest) else {
                return false;
            };
            point
                .split()
                .is_some_and(|(device, _)| current.guest_sees(&people.hub, &device))
        })
    }

    /// The person Cloudflare Access vouched for, if Moli knows the e-mail.
    pub(crate) fn by_email(&self, email: &str) -> Option<PersonRef> {
        let email = email.trim().to_lowercase();
        lock(&self.book)
            .people
            .iter()
            .find(|p| active(p, &self.hub) && p.emails.contains(&email))
            .map(Self::reference)
    }

    /// The person signed in by this request's cookie.
    pub(crate) fn signed_in(&self, headers: &HeaderMap) -> Option<PersonRef> {
        let token = cookie_token(headers)?;
        let session = lock(&self.sessions).get(&hash(token)).cloned()?;
        (now_ms().saturating_sub(session.created) < SESSION_MAX_AGE_S * 1000)
            .then(|| self.get(&session.person))
            .flatten()
    }

    fn account_reference(&self, id: &str) -> Option<PersonRef> {
        lock(&self.book)
            .people
            .iter()
            .find(|person| person.id == id && account_active_at(person, now_ms()))
            .map(Self::reference)
    }

    fn find_login(&self, login: &str) -> Option<Person> {
        let login = login.trim().to_lowercase();
        lock(&self.book)
            .people
            .iter()
            .find(|p| p.id == login || p.name.to_lowercase() == login || p.emails.contains(&login))
            .cloned()
    }

    /// Signs in with a password, behind the same lockouts as the house's
    /// code (per client, and for its side of the house: from the Internet,
    /// a budget apart from the household's).
    pub(crate) async fn login(
        &self,
        guard: &Sessions,
        login: &str,
        password: &str,
        caller: &Caller,
    ) -> Result<(String, PersonRef), LoginError> {
        let person = self
            .find_login(login)
            .filter(|person| account_active_at(person, now_ms()));
        let stored = person
            .as_ref()
            .and_then(|p| self.hub.core_secret(&password_key(&p.id)));
        guard.attempt(caller, || {
            stored
                .as_deref()
                .is_some_and(|s| password_matches(s, password))
        })?;
        let person = person.ok_or(LoginError::Wrong)?;
        let token = self.open_session(&person.id).await?;
        let reference = self
            .account_reference(&person.id)
            .ok_or(LoginError::Wrong)?;
        Ok((token, reference))
    }

    async fn open_session(&self, person: &str) -> Result<String, LoginError> {
        let token = token().ok_or(LoginError::Disabled)?;
        let max_age = SESSION_MAX_AGE_S * 1000;
        let json = {
            let mut sessions = lock(&self.sessions);
            sessions.retain(|_, s| now_ms().saturating_sub(s.created) < max_age);
            let mut mine: Vec<(String, u64)> = sessions
                .iter()
                .filter(|(_, s)| s.person == person)
                .map(|(k, s)| (k.clone(), s.created))
                .collect();
            mine.sort_by_key(|(_, c)| *c);
            while mine.len() >= MAX_SESSIONS_PER_PERSON {
                let (oldest, _) = mine.remove(0);
                sessions.remove(&oldest);
            }
            sessions.insert(
                hash(&token),
                PersonSession {
                    person: person.to_owned(),
                    created: now_ms(),
                },
            );
            serde_json::to_string(&*sessions).unwrap_or_default()
        };
        self.persist_sessions(json).await;
        Ok(token)
    }

    async fn persist_sessions(&self, json: String) {
        if let Err(e) = self.hub.store_core_secret(SESSIONS_KEY, &json).await {
            tracing::debug!(error = %e, "person sessions kept in memory only");
        }
    }

    pub(crate) async fn logout(&self, headers: &HeaderMap) {
        let Some(token) = cookie_token(headers) else {
            return;
        };
        let json = {
            let mut sessions = lock(&self.sessions);
            if sessions.remove(&hash(token)).is_none() {
                return;
            }
            serde_json::to_string(&*sessions).unwrap_or_default()
        };
        self.persist_sessions(json).await;
    }

    /// Ends every session of a person (password changed, person removed).
    async fn end_sessions(&self, person: &str) {
        let json = {
            let mut sessions = lock(&self.sessions);
            sessions.retain(|_, s| s.person != person);
            serde_json::to_string(&*sessions).unwrap_or_default()
        };
        self.persist_sessions(json).await;
    }

    pub(crate) fn cookie(token: &str) -> String {
        format!(
            "{COOKIE_NAME}={token}; HttpOnly; SameSite=Strict; Path=/; Max-Age={SESSION_MAX_AGE_S}"
        )
    }

    pub(crate) fn clear_cookie() -> String {
        format!("{COOKIE_NAME}=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0")
    }

    /// Whether this person has a password (else: Access, or an invitation).
    pub(crate) fn has_password(&self, id: &str) -> bool {
        self.hub.core_secret(&password_key(id)).is_some()
    }

    /// A new password: the person's sessions end, except the one that set it.
    pub(crate) async fn set_password(&self, id: &str, password: &str) -> Result<(), Refused> {
        let stored = self.prepare_password(id, password)?;
        self.replace_password(id, &stored).await
    }

    fn prepare_password(&self, id: &str, password: &str) -> Result<String, Refused> {
        let n = password.chars().count();
        if !(MIN_PASSWORD..=MAX_PASSWORD).contains(&n) {
            return Err(Refused::Invalid(moli_i18n::tr!(
                "serveur.personnes.mot_de_passe_court",
                min = MIN_PASSWORD
            )));
        }
        if self.get(id).is_none() {
            return Err(Refused::NotFound);
        }
        hash_password(password).ok_or(Refused::Store)
    }

    async fn replace_password(&self, id: &str, stored: &str) -> Result<(), Refused> {
        self.hub
            .store_core_secret(&password_key(id), stored)
            .await
            .map_err(|_| Refused::Store)?;
        self.end_sessions(id).await;
        Ok(())
    }

    /// An invitation for a person: a code to type, once, within 7 days.
    pub(crate) async fn invite(&self, id: &str) -> Result<(String, u64), Refused> {
        let code = invite_code().ok_or(Refused::Store)?;
        let expires = now_ms() + INVITE_TTL_MS;
        let digest = invite_digest(&self.new_invite_key().await?, &code);
        let person = id.to_owned();
        self.change(move |book| {
            if !book.people.iter().any(|p| p.id == person) {
                return Err(Refused::NotFound);
            }
            book.invites
                .retain(|i| i.person != person && i.expires > now_ms());
            book.invites.push(Invite {
                code_hmac: digest,
                code_sha256: None,
                person,
                expires,
            });
            Ok(())
        })
        .await?;
        Ok((code, expires))
    }

    /// The house's invitation key, from the encrypted store.
    fn invite_key(&self) -> Option<hmac::Key> {
        let key = unhex(&self.hub.core_secret(INVITE_KEY)?)?;
        Some(hmac::Key::new(hmac::HMAC_SHA256, &key))
    }

    /// The invitation key, made at the first invitation. Refused without a
    /// store (where no password could be kept either).
    async fn new_invite_key(&self) -> Result<hmac::Key, Refused> {
        // One at a time: two first invitations make one key.
        let _guard = self.write.lock().await;
        if let Some(key) = self.invite_key() {
            return Ok(key);
        }
        let mut raw = [0u8; 32];
        SystemRandom::new()
            .fill(&mut raw)
            .map_err(|_| Refused::Store)?;
        self.hub
            .store_core_secret(INVITE_KEY, &hex(&raw))
            .await
            .map_err(|_| Refused::Store)?;
        Ok(hmac::Key::new(hmac::HMAC_SHA256, &raw))
    }

    /// An invitation used: the person sets a password and is signed in.
    pub(crate) async fn redeem(
        &self,
        guard: &Sessions,
        code: &str,
        password: &str,
        caller: &Caller,
    ) -> Result<(String, PersonRef), Result<LoginError, Refused>> {
        // No key yet: no invitation was ever made.
        let typed = self
            .invite_key()
            .map(|house| invite_digest(&house, code))
            .unwrap_or_default();
        let found = invitation_person(&lock(&self.book), &typed, now_ms());
        guard.attempt(caller, || found.is_some()).map_err(Ok)?;
        let person = found.ok_or(Ok(LoginError::Wrong))?;
        let stored = self.prepare_password(&person, password).map_err(Err)?;
        // Reserve this use in the book under its writer before any
        // asynchronous password mutation. A competing request, cancellation
        // or later storage failure can never admit the same code twice.
        self.change(|book| {
            let current = invitation_person(book, &typed, now_ms());
            if current.as_deref() != Some(person.as_str()) {
                return Err(Refused::NotFound);
            }
            book.invites.retain(|i| i.code_hmac != typed);
            Ok(())
        })
        .await
        .map_err(|error| match error {
            Refused::NotFound => Ok(LoginError::Wrong),
            other => Err(other),
        })?;
        self.account_reference(&person)
            .ok_or(Ok(LoginError::Wrong))?;
        self.replace_password(&person, &stored).await.map_err(Err)?;
        self.account_reference(&person)
            .ok_or(Ok(LoginError::Wrong))?;
        let token = self.open_session(&person).await.map_err(Ok)?;
        let reference = self
            .account_reference(&person)
            .ok_or(Ok(LoginError::Wrong))?;
        Ok((token, reference))
    }

    /// A new person (an owner adds them).
    pub(crate) async fn create(&self, draft: Draft) -> Result<Person, Refused> {
        let draft = draft.checked()?;
        self.change(move |book| {
            if book.people.len() >= MAX_PEOPLE {
                return Err(Refused::Invalid(moli_i18n::tr!("serveur.personnes.trop")));
            }
            email_free(book, &draft.emails, None)?;
            let starts = draft.starts.apply(None);
            let expires = draft.expires.apply(None);
            checked_period(starts, expires)?;
            let person = Person {
                id: unique_id(book, &slug(&draft.name)),
                name: draft.name,
                role: draft.role,
                emails: draft.emails,
                color: draft.color,
                rooms: draft.rooms,
                starts,
                expires,
                reservation: match draft.reservation {
                    FieldChange::Keep => None,
                    FieldChange::Set(binding) => binding,
                },
                macs: draft.macs,
                created: now_ms(),
            };
            book.people.push(person.clone());
            Ok(person)
        })
        .await
    }

    pub(crate) async fn update(&self, id: &str, draft: Draft) -> Result<Person, Refused> {
        let draft = draft.checked()?;
        let id = id.to_owned();
        let out = self
            .change(move |book| {
                email_free(book, &draft.emails, Some(&id))?;
                let owners_left = book
                    .people
                    .iter()
                    .filter(|p| p.role == Role::Owner && p.id != id)
                    .count();
                let p = book
                    .people
                    .iter_mut()
                    .find(|p| p.id == id)
                    .ok_or(Refused::NotFound)?;
                if p.role == Role::Owner && draft.role != Role::Owner && owners_left == 0 {
                    return Err(Refused::LastOwner);
                }
                let starts = draft.starts.apply(p.starts);
                let expires = draft.expires.apply(p.expires);
                checked_period(starts, expires)?;
                p.name = draft.name;
                p.role = draft.role;
                p.emails = draft.emails;
                p.color = draft.color;
                p.rooms = draft.rooms;
                p.starts = starts;
                p.expires = expires;
                if let FieldChange::Set(binding) = draft.reservation {
                    p.reservation = binding;
                }
                p.macs = draft.macs;
                Ok(p.clone())
            })
            .await?;
        Ok(out)
    }

    pub(crate) async fn remove(&self, id: &str) -> Result<(), Refused> {
        let _write = self.write.lock().await;
        Self::removable(&lock(&self.book), id)?;
        // Serialize registration too: a dormant alarm cannot be opened between
        // revoking its profiles and committing the person removal.
        let registration = self.alarm_profiles.lock().await;
        let removal = if let Some(service) = registration
            .as_ref()
            .and_then(moli_alarm_access::ProfileRevoker::upgrade)
        {
            Some(
                service
                    .begin_person_removal(id)
                    .await
                    .map_err(|_| Refused::Store)?,
            )
        } else if let Some((hub, path)) = self.alarm_setup() {
            match std::fs::symlink_metadata(path.join("alarm-profiles.json")) {
                Ok(_) => Some(
                    moli_alarm_access::ProfileService::begin_person_removal_at(hub, &path, id)
                        .await
                        .map_err(|_| Refused::Store)?,
                ),
                Err(error) if error.kind() == std::io::ErrorKind::NotFound => None,
                Err(_) => return Err(Refused::Store),
            }
        } else {
            None
        };
        self.change_locked(|book| {
            Self::removable(book, id)?;
            book.people.retain(|person| person.id != id);
            book.invites.retain(|invite| invite.person != id);
            Ok(())
        })?;
        drop(removal);
        drop(registration);
        self.end_sessions(id).await;
        let _ = self.hub.forget_core_secret(&password_key(id)).await;
        Ok(())
    }

    fn removable(book: &Book, id: &str) -> Result<(), Refused> {
        let person = book
            .people
            .iter()
            .find(|p| p.id == id)
            .ok_or(Refused::NotFound)?;
        if person.role == Role::Owner
            && !book
                .people
                .iter()
                .any(|p| p.role == Role::Owner && p.id != id)
        {
            return Err(Refused::LastOwner);
        }
        Ok(())
    }

    pub(crate) async fn set_zones(&self, zones: Vec<Zone>) -> Result<Vec<Zone>, Refused> {
        if zones.len() > MAX_ZONES {
            return Err(Refused::Invalid(moli_i18n::tr!(
                "serveur.personnes.zones_trop"
            )));
        }
        let mut seen = std::collections::HashSet::new();
        for z in &zones {
            let ok = !z.id.is_empty()
                && z.id.len() <= 32
                && z.id.bytes().all(|b| b.is_ascii_alphanumeric() || b == b'-')
                && seen.insert(z.id.clone())
                && text_ok(&z.name, 40)
                && (-90.0..=90.0).contains(&z.latitude)
                && (-180.0..=180.0).contains(&z.longitude)
                && (20.0..=50_000.0).contains(&z.radius);
            if !ok {
                return Err(Refused::Invalid(moli_i18n::tr!(
                    "serveur.personnes.zone_invalide",
                    zone = z.name.clone()
                )));
            }
        }
        self.change(move |book| {
            book.zones.clone_from(&zones);
            Ok(zones)
        })
        .await
    }
}

fn unique_id(book: &Book, base: &str) -> String {
    let mut id = base.to_owned();
    let mut n = 2;
    while book.people.iter().any(|p| p.id == id) || id == "maison" {
        id = format!("{base}-{n}");
        n += 1;
    }
    id
}

fn email_free(book: &Book, emails: &[String], except: Option<&str>) -> Result<(), Refused> {
    for e in emails {
        if book
            .people
            .iter()
            .any(|p| Some(p.id.as_str()) != except && p.emails.contains(e))
        {
            return Err(Refused::Invalid(moli_i18n::tr!(
                "serveur.personnes.email_pris",
                email = e.clone()
            )));
        }
    }
    Ok(())
}

/// A person as an owner writes it (`POST`/`PUT /api/people`).
#[derive(Clone, Debug, Deserialize)]
#[serde(deny_unknown_fields)]
pub(crate) struct Draft {
    pub(crate) name: String,
    pub(crate) role: Role,
    #[serde(default)]
    pub(crate) emails: Vec<String>,
    #[serde(default)]
    pub(crate) color: Option<String>,
    #[serde(default)]
    pub(crate) rooms: Vec<String>,
    #[serde(default)]
    pub(crate) starts: FieldChange<u64>,
    #[serde(default)]
    pub(crate) expires: FieldChange<u64>,
    #[serde(default)]
    pub(crate) reservation: FieldChange<moli_runtime::ReservationRef>,
    #[serde(default)]
    pub(crate) macs: Vec<String>,
}

#[derive(Clone, Debug, Default)]
pub(crate) enum FieldChange<T> {
    #[default]
    Keep,
    Set(Option<T>),
}
impl<T> FieldChange<T> {
    fn apply(self, previous: Option<T>) -> Option<T> {
        match self {
            Self::Keep => previous,
            Self::Set(value) => value,
        }
    }
}
impl<'de, T: Deserialize<'de>> Deserialize<'de> for FieldChange<T> {
    fn deserialize<D: serde::Deserializer<'de>>(deserializer: D) -> Result<Self, D::Error> {
        Option::<T>::deserialize(deserializer).map(Self::Set)
    }
}

fn checked_period(starts: Option<u64>, expires: Option<u64>) -> Result<(), Refused> {
    let bad_order = starts.zip(expires).is_some_and(|(start, end)| start >= end);
    let invalid_time = starts.into_iter().chain(expires).any(|value| {
        i64::try_from(value)
            .ok()
            .and_then(|value| jiff::Timestamp::from_millisecond(value).ok())
            .is_none()
    });
    if bad_order || invalid_time {
        return Err(Refused::Invalid(moli_i18n::tr!(
            "serveur.personnes.periode_invalide"
        )));
    }
    Ok(())
}

impl Draft {
    fn checked(mut self) -> Result<Self, Refused> {
        let bad = |what: &str| {
            Err(Refused::Invalid(moli_i18n::tr!(
                "serveur.personnes.champ",
                champ = what.to_owned()
            )))
        };
        self.name = self.name.trim().to_owned();
        if !text_ok(&self.name, 40) {
            return bad("name");
        }
        self.emails = self
            .emails
            .iter()
            .map(|e| e.trim().to_lowercase())
            .filter(|e| !e.is_empty())
            .collect();
        if self.emails.len() > 5
            || self
                .emails
                .iter()
                .any(|e| e.len() > 120 || !e.contains('@') || e.chars().any(char::is_whitespace))
        {
            return bad("emails");
        }
        if self.color.as_deref().is_some_and(|c| {
            !(c.len() == 7 && c.starts_with('#') && c[1..].bytes().all(|b| b.is_ascii_hexdigit()))
        }) {
            return bad("color");
        }
        if self.rooms.len() > 30 || self.rooms.iter().any(|r| !text_ok(r, 60)) {
            return bad("rooms");
        }
        self.macs = self.macs.iter().map(|m| m.trim().to_lowercase()).collect();
        if self.macs.len() > 10
            || self.macs.iter().any(|m| {
                m.len() != 17
                    || !m
                        .split(':')
                        .all(|o| o.len() == 2 && o.bytes().all(|b| b.is_ascii_hexdigit()))
            })
        {
            return bad("macs");
        }
        if self.role != Role::Guest {
            self.rooms.clear();
            self.starts = FieldChange::Set(None);
            self.expires = FieldChange::Set(None);
            self.reservation = FieldChange::Set(None);
        } else if matches!(&self.reservation, FieldChange::Set(Some(binding)) if !binding.valid()) {
            return bad("reservation");
        }
        Ok(self)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use moli_runtime::HubOptions;

    fn hub() -> Hub {
        Hub::new(HubOptions::default()).unwrap()
    }

    /// Someone on the Internet, where invitations and passwords come from.
    pub(super) fn stranger(key: &str) -> Caller {
        Caller {
            via: crate::caller::Via::Outside,
            key: key.to_owned(),
            person: None,
        }
    }

    /// A hub with an encrypted store (passwords need one), each its own
    /// (two tests in the same millisecond would share a file).
    pub(super) fn hub_with_store() -> Hub {
        static NEXT: std::sync::atomic::AtomicUsize = std::sync::atomic::AtomicUsize::new(0);
        let path = std::env::temp_dir().join(format!(
            "moli-people-secrets-{}-{}-{}.enc",
            std::process::id(),
            now_ms(),
            NEXT.fetch_add(1, std::sync::atomic::Ordering::Relaxed)
        ));
        Hub::new(HubOptions {
            secrets: Some((path, moli_runtime::MasterKey::generate().unwrap())),
            ..HubOptions::default()
        })
        .unwrap()
    }

    pub(super) fn draft(name: &str, role: Role) -> Draft {
        Draft {
            name: name.into(),
            role,
            emails: Vec::new(),
            color: None,
            rooms: Vec::new(),
            starts: FieldChange::Keep,
            expires: FieldChange::Keep,
            reservation: FieldChange::Keep,
            macs: Vec::new(),
        }
    }

    #[test]
    fn passwords_are_salted_and_checked() {
        let a = hash_password("correct horse battery").unwrap();
        let b = hash_password("correct horse battery").unwrap();
        assert_ne!(a, b, "salted");
        assert!(password_matches(&a, "correct horse battery"));
        assert!(!password_matches(&a, "correct horse batterY"));
        assert!(!password_matches("garbage", "x"));
    }

    #[test]
    fn ids_come_from_names() {
        assert_eq!(slug("Élodie"), "elodie");
        assert_eq!(slug("  Jean-Él ève "), "jean-el-eve");
        assert_eq!(slug("!!!"), "personne");
    }

    #[test]
    fn access_owners_become_owners_once() {
        let dir = std::env::temp_dir().join(format!("moli-people-{}", now_ms()));
        std::fs::create_dir_all(&dir).unwrap();
        let owners = vec!["Moi@Example.org".to_owned()];
        let p = People::open(hub(), Some(&dir), &owners);
        let me = p.by_email("moi@example.org").unwrap();
        assert_eq!((me.id.as_str(), me.role), ("moi", Role::Owner));
        drop(p);
        let p = People::open(hub(), Some(&dir), &owners);
        assert_eq!(p.book().people.len(), 1, "not added twice");
        let _ = std::fs::remove_dir_all(&dir);
    }

    #[tokio::test]
    async fn the_last_owner_stays() {
        let p = People::open(hub(), None, &["a@example.org".to_owned()]);
        assert_eq!(p.remove("a").await, Err(Refused::LastOwner));
        assert_eq!(
            p.update("a", draft("A", Role::Member)).await.err(),
            Some(Refused::LastOwner)
        );
        let b = p.create(draft("B", Role::Owner)).await.unwrap();
        p.remove("a").await.unwrap();
        assert!(p.get(&b.id).is_some());
    }

    #[tokio::test]
    async fn an_invitation_sets_a_password_once() {
        let hub = hub_with_store();
        let guard = Sessions::new(hub.clone(), Some(crate::UiPin::new("123456")), &[]);
        let p = People::open(hub, None, &[]);
        let elodie = p.create(draft("Élodie", Role::Member)).await.unwrap();
        let (code, _) = p.invite(&elodie.id).await.unwrap();
        let typed = code.to_lowercase().replace('-', " ");
        let short = p.redeem(&guard, &typed, "court", &stranger("k")).await;
        assert!(
            matches!(short, Err(Err(Refused::Invalid(_)))),
            "password too short"
        );
        let (token, who) = p
            .redeem(&guard, &typed, "un mot de passe long", &stranger("k"))
            .await
            .unwrap();
        assert_eq!(who.id, "elodie");
        let mut headers = HeaderMap::new();
        headers.insert(COOKIE, format!("{COOKIE_NAME}={token}").parse().unwrap());
        assert_eq!(p.signed_in(&headers).unwrap().id, "elodie");
        assert!(
            p.redeem(&guard, &code, "un mot de passe long", &stranger("k"))
                .await
                .is_err(),
            "once"
        );
        let (_, again) = p
            .login(&guard, "ELODIE", "un mot de passe long", &stranger("k2"))
            .await
            .unwrap();
        assert_eq!(again.role, Role::Member);
        assert_eq!(
            p.login(&guard, "elodie", "faux mot de passe", &stranger("k3"))
                .await
                .err(),
            Some(LoginError::Wrong)
        );
    }

    #[tokio::test]
    async fn an_expired_guest_cannot_sign_in() {
        let hub = hub();
        let guard = Sessions::new(hub.clone(), None, &[]);
        let p = People::open(hub, None, &[]);
        let mut d = draft("Invité", Role::Guest);
        d.expires = FieldChange::Set(Some(1));
        let g = p.create(d).await.unwrap();
        p.set_password(&g.id, "un mot de passe long")
            .await
            .unwrap_err();
        assert!(p.get(&g.id).is_none());
        assert!(
            p.login(&guard, &g.id, "un mot de passe long", &stranger("k"))
                .await
                .is_err()
        );
    }

    /// A data folder of its own.
    fn folder(name: &str) -> std::path::PathBuf {
        let dir = std::env::temp_dir().join(format!(
            "moli-people-{name}-{}-{}",
            std::process::id(),
            now_ms()
        ));
        std::fs::create_dir_all(&dir).unwrap();
        dir
    }

    #[tokio::test]
    async fn an_invitation_code_cannot_be_tried_against_the_file() {
        let dir = folder("hmac");
        let hub = hub_with_store();
        let guard = Sessions::new(hub.clone(), Some(crate::UiPin::new("123456")), &[]);
        let p = People::open(hub.clone(), Some(&dir), &[]);
        let sam = p.create(draft("Sam", Role::Member)).await.unwrap();
        let (code, _) = p.invite(&sam.id).await.unwrap();
        let kept = std::fs::read_to_string(dir.join(FILE)).unwrap();
        // Neither the code nor its bare digest: the key is in the store.
        assert!(!kept.contains(&plain_code(&code)));
        assert!(!kept.contains(&hash(&plain_code(&code))), "{kept}");
        assert!(kept.contains("code_hmac"));
        assert!(hub.core_secret(INVITE_KEY).is_some());
        #[cfg(unix)]
        {
            use std::os::unix::fs::PermissionsExt as _;
            let mode = std::fs::metadata(dir.join(FILE))
                .unwrap()
                .permissions()
                .mode();
            assert_eq!(mode & 0o777, 0o600, "for Moli's user alone");
        }
        // The code itself works, once.
        let long = "un mot de passe long";
        assert!(p.redeem(&guard, &code, long, &stranger("k")).await.is_ok());
        assert!(p.redeem(&guard, &code, long, &stranger("k")).await.is_err());
        // No store, no key: no invitation either.
        let bare = People::open(self::hub(), None, &[]);
        let alone = bare.create(draft("Seul", Role::Member)).await.unwrap();
        assert_eq!(bare.invite(&alone.id).await.err(), Some(Refused::Store));
        let _ = std::fs::remove_dir_all(&dir);
    }

    #[tokio::test]
    async fn an_invitation_of_an_older_kind_opens_nothing() {
        let dir = folder("old-invite");
        let hub = hub_with_store();
        let guard = Sessions::new(hub.clone(), Some(crate::UiPin::new("123456")), &[]);
        // As an older version kept it: the code's bare SHA-256.
        let old = serde_json::json!({
            "people": [{ "id": "sam", "name": "Sam", "role": "member", "created": 1 }],
            "invites": [{
                "code_sha256": hash("ABCDEFGH"),
                "person": "sam",
                "expires": now_ms() + 3_600_000,
            }],
        });
        std::fs::write(dir.join(FILE), old.to_string()).unwrap();
        let p = People::open(hub, Some(&dir), &[]);
        assert!(p.get("sam").is_some(), "the people are still known");
        assert_eq!(
            p.redeem(&guard, "ABCD-EFGH", "un mot de passe long", &stranger("k"))
                .await
                .err(),
            Some(Ok(LoginError::Wrong)),
            "never taken unverified"
        );
        let kept = std::fs::read_to_string(dir.join(FILE)).unwrap();
        assert!(!kept.contains("code_sha256"), "{kept}");
        let _ = std::fs::remove_dir_all(&dir);
    }
}

#[cfg(test)]
mod guest_starts_tests {
    use super::*;
    use serde_json::json;
    fn visitor() -> Person {
        serde_json::from_value(json!({"id":"visitor","name":"Synthetic guest","role":"guest","starts":1000,"expires":2000})).unwrap()
    }
    #[test]
    fn guest_starts_is_inclusive_and_expiry_is_exclusive() {
        let guest = visitor();
        for (now, allowed) in [
            (0, false),
            (999, false),
            (1000, true),
            (1999, true),
            (2000, false),
            (u64::MAX, false),
        ] {
            assert_eq!(account_active_at(&guest, now), allowed, "timestamp {now}");
        }
    }
    #[test]
    fn optional_bounds_and_largest_timestamps_do_not_overflow() {
        let mut guest = visitor();
        guest.starts = None;
        guest.expires = None;
        assert!(account_active_at(&guest, 0));
        assert!(account_active_at(&guest, u64::MAX));
        guest.starts = Some(u64::MAX);
        assert!(!account_active_at(&guest, u64::MAX - 1));
        assert!(account_active_at(&guest, u64::MAX));
    }
}

#[cfg(test)]
#[path = "people/redemption_tests.rs"]
mod redemption_tests;
