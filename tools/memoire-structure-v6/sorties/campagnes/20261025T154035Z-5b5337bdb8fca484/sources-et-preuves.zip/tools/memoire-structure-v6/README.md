# V6 : preuve de structures, isolée du produit

Ce dossier est un **prototype synthétique**, compilé directement avec `rustc`, sans
dépendance. Il n'importe aucun code du moteur et ne contient aucune donnée de maison.
Il ne contacte ni réseau ni appareil. Ce n'est ni un moteur livré, ni un nouveau banc
de latence, ni une preuve de mémoire RSS. Les campagnes V2–V5 restent les preuves
de performance de leurs implémentations respectives.

`main.rs --layouts` émet taille, alignement et **tous** les offsets des 18 structures.
Les formes Row64/Row96/Numeric32/Hot32/Cold32 reprennent le banc catalogue ; Alias32
reprend le banc orientations (les champs de cache sont nommés `source_slot` et
`source_generation`) ; Edge24/Target12 reprennent le banc organisation.
Schema64, Transform64 et Calc48 font respectivement 64, 64 et 48 octets sans `packed`.
Les layouts C en RAM ne sont pas un format de fichier ni un protocole inter-machine.

Le modèle `Bank` stocke les lignes canoniques Row96 et les alias dans deux Vec.
L'identité u64 ne dépend ni du nom, ni de l'offset dans un Vec. Un slot global 16
octets situe chaque nœud ; ses métadonnées 32 octets sont séparées. Le HashMap associe
l'identité au couple slot/génération. Renommer ne touche que la métadonnée ; compacter
ne change que les indices physiques. Aucune adresse de Vec n'est gardée.

Lire un alias vérifie l'epoch du lecteur, sa propre génération, la génération et
l'identité de la source. Une source alias est aplatie à la création ; le stockage
n'a jamais de chaîne d'alias. Une suppression suivie d'un réemploi invalide les caches.
Générations et epochs ne rebouclent pas : leur épuisement est refusé. Les IDs sont
fournis par l'appelant : un allocateur durable d'ID reste à développer pour le produit.

Un alias n'a pas de copie d'état. Une observation canonique devient visible par tous
ses alias. Un calcul possède sa ligne et son état propres ; ici le test injecte son
résultat, **aucun ordonnanceur de calcul n'est implémenté**. `intent` renvoie seulement
un destinataire physique et un point canonique, sans muter l'observation. Il distingue
écriture et lecture active. Validation métier complète, garde, contrôle d'origine,
pilote, délais, journal et confirmation d'état doivent rester dans le Hub du produit.

La topologie impose famille → maison → étage facultatif → pièce ; équipements
physiques/virtuels sous maison ou pièce ; valeurs/actions/calculs sous équipement.
Une zone fonctionnelle appartient à une maison et référence pièces/équipements par
arêtes, sans copier leurs lignes. Plusieurs zones peuvent se recouvrir. La géozone
est une ressource distincte, refusée comme zone fonctionnelle. Les liens de zone
entre maisons, parents absents, cycles et déplacements qui invalident une zone sont
refusés. Ce modèle n'est pas un catalogue complet des relations métier.

Edge24 est la source durable **en RAM** des liens parent/enfant et appartenances ;
« durable » ne signifie pas persisté sur disque. Le CSR avant ajoute Target12 et ses
offsets u32 ; le CSR inverse ajoute des indices d'arêtes u32 et ses propres offsets.
Les trois coûts sont cumulés. Le CSR emprunte Bank immuablement : Rust interdit les
mutations tant qu'il est utilisé. Les mutations ordinaires requièrent `&mut Bank`.
Ce n'est pas une stratégie de concurrence pour un moteur multi-lecteur.

Les blobs ont un descripteur PoolEntry16, génération, type et bornes contrôlées :
4 Kio par valeur, 1 Mio d'octets et 65 536 descripteurs pour le pool synthétique
(les valeurs vides consomment aussi un descripteur). Le composite d'exemple est décodé
en little endian explicitement, jamais par transmutation : version u32, nombre u16,
réservé u16 nul, puis couples clé u32 / bits de valeur u64 ; 64 champs au plus,
aucune clé dupliquée. Une mise à jour valide intégralement taille et version avant
de publier un nouveau descripteur et une nouvelle version ensemble sous `&mut`.
Le pool est append-only et conserve les anciennes versions ; récupération,
déduplication et persistance restent hors périmètre. Le format illustre une preuve
de remplacement atomique, pas toutes les valeurs composites du futur produit.

`alternatives.rs` matérialise aussi Row64 + annexe Numeric32 + une référence u32
par ligne canonique, et Hot32 + Cold32 avec la même annexe et les mêmes références.
Le masque des schémas numériques est explicite : une valeur numérique encore Null
peut avoir des limites ; le masque ne se déduit pas de la dernière valeur observée.
Le test reconstruit tous les champs des lignes. La représentation active de Bank
reste Row96 ; aucune latence comparative n'est annoncée pour ces alternatives.

## Comptage : aucun alias à « 32 octets tout compris »

`--demo` émet des nœuds/liens synthétiques, les résolutions d'alias et les capacités
réelles des Vec du modèle actif. `used_bytes = len × size_of`,
`capacity_bytes = capacity × size_of`. Ce sont les octets d'éléments réservés, sans
surcoût d'allocateur, fragmentation, piles, objets Vec/Bank ou allocations temporaires.
Le HashMap expose len/capacité et les **seuls octets de clés/valeurs utiles** ; ses
octets de buckets, contrôle, capacité libre et alignement ne sont pas mesurés.
`allocation_bytes: null` indique cette absence de mesure. Aucun total RSS n'est inféré.

Pour N canoniques, M schémas numériques, A alias, S slots alloués et E arêtes :

| Partie | Octets utiles, sans capacité excédentaire |
|---|---:|
| Canonique Row96 | 96 N |
| Alternative Row64/Hot32+Cold32 + Numeric32 + références | 68 N + 32 M |
| Alias | 32 A |
| Slots globaux + métadonnées | 48 S |
| Arêtes sources + CSR avant + CSR inverse | 40 E + 8 (S + 1) |
| Clés u64 + valeurs Handle8 utiles du HashMap | 16 (N + A), **pas son allocation** |
| Descripteurs et octets du pool | 16 P + B |

Sans trous, S = N + A : une ligne Row96 atteint déjà **144 octets** et un alias
**80 octets** avec slot et métadonnée, avant index, relations, pools et autres tables.
Après suppressions, les slots et métadonnées libres restent réservés. Schema64,
Transform64, Component32, Calc48 et Route32 ont des layouts testés mais **aucune
instance en Vec dans ce Bank minimal**. Ils s'ajoutent selon leurs nombres réels :
64 Q + 64 T + 32 C + 48 K + 32 R. Les textes, plans et règles référencés par Meta32
ne sont pas implicitement gratuits : leurs contenus et index restent à budgéter.

## Reproduire

Depuis la racine du dépôt, avec l'image de développement déjà disponible :

```sh
docker run --rm --network none -v "$PWD/tools/memoire-structure-v6:/bench:ro" moli-os-dev:latest sh -c 'rustc --edition=2024 -D warnings --test /bench/main.rs -o /tmp/structure-tests && /tmp/structure-tests'
docker run --rm --network none -v "$PWD/tools/memoire-structure-v6:/bench:ro" moli-os-dev:latest sh -c 'rustc --edition=2024 -D warnings -O /bench/main.rs -o /tmp/structure && /tmp/structure --layouts'
docker run --rm --network none -v "$PWD/tools/memoire-structure-v6:/bench:ro" moli-os-dev:latest sh -c 'rustc --edition=2024 -D warnings -O /bench/main.rs -o /tmp/structure && /tmp/structure --demo'
```

Les fichiers `layouts.json` et `demo.json` proviennent de ces deux sorties, sur
linux/aarch64, pointeurs 64 bits, little endian. La commande de tests couvre tailles,
offsets sensibles, alternatives, alias, identités, slots, epochs, topologie, zones,
CSR, null/zéro, accès, horodatages distincts et composites malformés. Aucun secret,
flux MQTT réel ni état HA brut ne sert de fixture.

## Dimensionnement et conservation

Depuis la racine, avec Python standard et Docker :

```sh
python3 tools/memoire-structure-v6/executer.py
python3 tools/memoire-structure-v6/rapport.py
python3 tools/memoire-structure-v6/verifier.py
python3 tools/memoire-structure-v6/archiver.py
```

Le lanceur fige les sources pendant la compilation et les 13 tests. Il mesure aussi
23 réservations de `HashMap<u64,Handle8>`, jusqu’à 1 613 600 entrées. Le probe a son
allocateur de comptage : octets demandés, sans mesure RSS ni latence. Les tables plus
grandes sont extrapolées selon les buckets de cette toolchain.

`budget.py` calcule 12 scénarios et 3 variantes depuis les formes anonymisées A/B/somme.
Hypothèses et exclusions figurent dans `sorties/budgets.json`. Les alternatives V6
comptent une référence numérique de 4 octets par canonique : `aux` reste disponible
pour un composant typé. Ce coût diffère de celui du microbanc V2.

Les mesures V2–V5 sont importées avec leur périmètre propre ; leurs totaux ne sont
pas additionnés. Alias, zones, calculs et métadonnées ajoutés sont synthétiques.
Les données HA brutes et conversations privées restent hors de ce dossier.

Le rapport est `docs/proposition/analyse/catalogue-memoire-v6.html`. L’archive conserve
sources, résultats, entrées synthétiques publiques, mesures importées et empreintes.
Un changement de source ou d’entrée crée une capture distincte. Les fichiers sont
à replacer à la racine d’une copie du dépôt pour conserver les chemins des outils.
