/* Tests de contrats de la leçon ; aucune requête réseau, aucun benchmark CPU. */
(() => {
  'use strict';
  window.runMemoryLessonChecks = function () {
    const lesson = window.memoryLesson;
    const results = [];
    let assertions = 0;
    const check = (condition, message) => {
      assertions++;
      if (!condition) throw new Error(message);
    };
    const equal = (actual, expected, message) => check(JSON.stringify(actual) === JSON.stringify(expected), message);
    const close = (actual, expected, message) => check(Math.abs(actual - expected) < 1e-10, message);
    for (const mode of ['source_unique', 'alias_topics']) {
      lesson.setMode(mode);
      for (const name of ['mqtt', 'api', 'command', 'blocked', 'same', 'action']) {
        let s = lesson.choose(name);
        const frames = [s];
        const initial = {101:21, 201:23, 301:50, 904:22};
        equal(s.values, initial, name + ': état initial');
        for (let index = 0; index < s.total; index++) {
          if (index) { s = lesson.next(); frames.push(s); }
          check(s.index === index, name + ': index étape');
          equal(Object.keys(s.state.points).sort(), ['101', '201', '301', '904'], name + ': pas de ligne d’état créée');
          equal(Object.keys(s.values).sort(), ['101', '201', '301', '904'], name + ': quatre états propres');
          check(s.stats.alias_writes === 0, name + ': aucun état alias écrit');
          for (const alias of s.aliases) {
            check(!Object.hasOwn(alias, 'value') && !Object.hasOwn(alias, 'payload'), name + ': alias sans état');
            close(s.resolved_alias_values[alias.id], s.values[alias.source_id], name + ': résolution source');
          }
          check(s.stats.temporary_live >= 0, name + ': temporaires bornés par leur durée de vie');
          check(s.stats.temporary_created - s.stats.temporary_freed === s.stats.temporary_live, name + ': bilan temporaires');
          check(s.stats.permanent_delta_bytes === 0, name + ': pas de croissance du catalogue');
          check(s.stats.publications === s.notifications.length, name + ': bilan publications');
          check(s.stats.commands === s.outgoing.length, name + ': bilan ordres');
          check(s.outgoing.every(x => x.locally_queued && x.broker_acknowledged === false && x.physical_confirmed === false), name + ': file locale distincte de livraison et effet');
          if (name === 'command' && s.stats.source_writes === 0) close(s.values[301], 50, 'ACK/ordre ne changent pas la mesure');
          if (name === 'mqtt' || name === 'api') {
            close(s.values[201], 23, 'source B inchangée');
            close(s.values[301], 50, 'lampe inchangée par température');
            close(s.values[904], s.stats.calculation_writes ? 22.25 : 22, 'résultat seulement à son étape');
          }
          if (name === 'blocked' || name === 'action' || name === 'same') equal(s.values, initial, name + ': états numériques inchangés');
        }
        const final = s;
        check(final.stats.temporary_live === 0, name + ': nettoyage des temporaires');
        if (name === 'mqtt' || name === 'api') {
          equal(final.values, {101:21.5, 201:23, 301:50, 904:22.25}, name + ': état final');
          check(final.stats.source_writes === 1 && final.stats.calculation_writes === 1, name + ': une source et un résultat');
          check(final.notifications.length === (mode === 'alias_topics' ? 4 : 2), name + ': coût de publication');
          check(final.timestamps[904].observed === 1000, name + ': fraîcheur du calcul = plus ancienne source');
          check(final.timestamps[101].observed === 1900 && final.timestamps[101].changed === 1900 && final.timestamps[101].received === 2000, name + ': changement daté côté source, réception distincte comme Rust');
          check(final.outgoing.length === 0, name + ': aucune commande');
        } else if (name === 'command') {
          check(final.outgoing.length === 1 && final.outgoing[0].payload.brightness === 203, '80 % arrondis à 203 natif');
          check(final.outgoing[0].retain === false, 'ordre non retenu');
          check(!Object.hasOwn(final.fixture.command.body, 'request_id'), 'commande scalaire sans identité réservée aux boutons');
          close(final.values[301], 203 * 100 / 254, 'retour natif converti, pas 80 forcé');
          check(final.timestamps[301].changed === final.timestamps[301].observed && final.timestamps[301].received === 2000, 'changement lampe daté côté source comme Rust');
          check(final.notifications.length === (mode === 'alias_topics' ? 2 : 1), 'publication retour lampe');
          check(final.stats.source_writes === 1 && final.stats.calculation_writes === 0, 'seul retour écrit la source');
          check(frames.some(x => x.outgoing.length === 1 && x.values[301] === 50), 'ordre accepté avant retour observé');
          check(final.pending === null, 'attente documentaire terminée après le retour');
        } else if (name === 'blocked') {
          check(final.outgoing.length === 0 && final.notifications.length === 0, 'refus sans émission');
          check(final.stats.source_writes === 0 && final.stats.calculation_writes === 0, 'refus sans écriture d’état');
          check(final.state.journal.some(x => x.status === 'refused'), 'refus journalisé');
        } else if (name === 'same') {
          check(final.notifications.length === 0 && final.stats.calculation_writes === 0, 'pas de faux changement numérique');
          check(final.timestamps[101].observed === 1900 && final.timestamps[101].received === 2000, 'fraîcheur renouvelée');
          check(final.timestamps[101].changed === 1000, 'date du changement conservée');
        } else {
          check(final.outgoing.length === 2 && final.occurrences.length === 2, 'deux appels = deux occurrences');
          check(new Set(final.occurrences.map(x => x.request_id)).size === 2, 'identités distinctes pour deux appuis');
          check(final.occurrences.every(x => /^[0-9a-f]{32}:[1-9][0-9]*$/.test(x.request_id)), 'identités de bouton au format actuel');
          check(final.outgoing.every(x => x.retain === false), 'actions non retenues');
          check(final.stats.source_writes === 0 && final.notifications.length === 0, 'actions sans faux état observé');
        }
        for (let index = frames.length - 2; index >= 0; index--) {
          const previous = lesson.previous();
          equal(previous.state, frames[index].state, name + ': précédent restaure exactement état et files');
        }
        equal(lesson.reset().values, initial, name + ': retour au début');
        results.push({case:name, mode, steps:frames.length, source_writes:final.stats.source_writes, alias_writes:final.stats.alias_writes, calculation_writes:final.stats.calculation_writes, publications:final.stats.publications, commands:final.stats.commands});
      }
    }
    lesson.setMode('source_unique'); lesson.choose('mqtt');
    return {status:'pass', scope:'Simulation documentaire JavaScript, sans moteur Rust, réseau, timings CPU ni RSS.', cases:results.length, assertions, results};
  };
})();
